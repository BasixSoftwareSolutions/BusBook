﻿
Friend Class frmManageLayoverZones

    Private Sub cmdLayoverZoneProcess_Click(sender As Object, e As EventArgs) Handles cmdLayoverZoneProcess.Click

        If MsgBox("Remove Remote Layover Zone Timepoints and perform QA/QC?", MsgBoxStyle.OkCancel + MsgBoxStyle.Question, "Remote Layover Zone Timepoints and QA/QC") = MsgBoxResult.Cancel Then Exit Sub
        On Error GoTo ErrHandler
        Me.Cursor = System.Windows.Forms.Cursors.WaitCursor
        Call RemoveRLZ()
        Me.ProgressBar1.Visible = False
        Me.lblMsg.Visible = False
        Me.Cursor = System.Windows.Forms.Cursors.Default
        Exit Sub

lblCancel:
        Exit Sub
ErrHandler:
        Me.Cursor = System.Windows.Forms.Cursors.Default
        MsgBox(Err.Source & ": " & Err.Description, MsgBoxStyle.Exclamation, System.Reflection.Assembly.GetExecutingAssembly.GetName.Name)

    End Sub

    Public Sub InitSeq()
        Dim strSQL As String

        strSQL = "TRUNCATE TABLE dbo.tblRouteStops"
        db.Execute(strSQL)

    End Sub

    Public Sub GetSeq(ByRef vRte As Integer, ByRef vDay As Integer, ByRef vDir As Integer)
        Dim strSQL As String
        Dim rs As New ADODB.Recordset
        Dim vSeq As Integer
        Dim vFPl, vBPl As String

        On Error GoTo ErrHandling

        db.Execute("TRUNCATE TABLE dbo.tblRouteStops")
        db.Execute("TRUNCATE TABLE dbo.tmpMissingTimepoints")
        db.Execute("TRUNCATE TABLE dbo.tmpRouteStops")

        strSQL = "INSERT INTO dbo.tblRouteStops SELECT * FROM dbo.tblTimepointSeq WHERE route=" & vRte & " AND dir=" & vDir
        strSQL = strSQL & " AND place_id IS NOT NULL AND Seq IS NOT NULL AND DAYS=" & vDay
        db.Execute(strSQL)

        'db.Execute("UPDATE dbo.tblRouteStops SET Seq = Seq * 10")

        strSQL = "SELECT * FROM dbo.tblMissingTimepoints WHERE route=" & vRte & " AND dir=" & vDir
        strSQL = strSQL & " AND days=" & vDay & " AND place IS NOT NULL"
        rs.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockReadOnly)

        Do While Not rs.EOF
            vBPl = FilterNull((rs.Fields("back_place").Value))
            vFPl = FilterNull((rs.Fields("forward_pl").Value))
            vSeq = FindSeq(vFPl, vBPl)

            If vSeq = -1 Then
                strSQL = "INSERT INTO dbo.tmpMissingTimepoints (place,forward_pl,back_place) VALUES ("
                strSQL = strSQL & cV2Q_String((rs.Fields("place").Value)) & ",'" & vFPl & "','" & vBPl & "')"
                db.Execute(strSQL)
            Else
                strSQL = "INSERT INTO dbo.tblRouteStops (route,dir,place_id,seq,days) VALUES (" & vRte & ","
                strSQL = strSQL & vDir & "," & cV2Q_String((rs.Fields("place").Value)) & "," & vSeq & "," & vDay & ")"
                db.Execute(strSQL)
            End If
            rs.MoveNext()
        Loop
        rs.Close()

        'try one more time for place that its sequence could not be found
        strSQL = "SELECT * FROM dbo.tmpMissingTimepoints WHERE route=" & vRte & " AND dir=" & vDir
        strSQL = strSQL & " AND days=" & vDay & " AND place IS NOT NULL"
        rs.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockOptimistic, ADODB.CommandTypeEnum.adCmdText)

        Do While Not rs.EOF
            vBPl = FilterNull((rs.Fields("back_place").Value))
            vFPl = FilterNull((rs.Fields("forward_pl").Value))
            vSeq = FindSeq(vFPl, vBPl)
            strSQL = "INSERT INTO RouteStops (route,dir,place_id,seq,days) VALUES (" & vRte & ","
            strSQL = strSQL & vDir & "," & cV2Q_String(rs.Fields("place").Value) & "," & vSeq & "," & vDay & ")"
            db.Execute(strSQL)
            rs.MoveNext()
        Loop
        rs.Close()

        strSQL = "SELECT 0,Seq,Place_ID FROM dbo.tblRouteStops WHERE Route=" & vRte & " AND Dir=" & vDir & " AND Days=" & vDay & " ORDER BY Seq"
        rs.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockReadOnly)

        strSQL = "INSERT INTO dbo.tmpRouteStops (Seq,Place_ID) "
        strSQL = strSQL & "SELECT Seq,Place_ID FROM dbo.tblRouteStops WHERE Route=" & vRte & " AND Dir=" & vDir & " AND Days=" & vDay & " ORDER BY Seq"
        db.Execute(strSQL)

        rs = Nothing
        Exit Sub

ErrHandling:

        MsgBox("Error occurred while read timepoint sequence for Route: " & vRte & ", Direction: " & vDir & ", Day: " & vDay)
        If rs.State = ADODB.ObjectStateEnum.adStateOpen Then rs.Close()

    End Sub

    Public Function FindSeq(ByRef FPL As String, ByRef BPL As String) As Integer
        Dim BSeq, FSeq, vSeq As Integer
        Dim rsStops As New ADODB.Recordset
        Dim strSQL As String

        vSeq = -1
        If BPL <> "" And FPL <> "" Then
            strSQL = "SELECT Seq FROM dbo.tblRouteStops WHERE Place_ID = " & cV2Q_String(BPL)
            rsStops.Open(strSQL, db)
            If rsStops.EOF Then
                BSeq = -1
            Else
                BSeq = rsStops.Fields("Seq").Value
            End If
            rsStops.Close()
            strSQL = "SELECT Seq FROM dbo.tblRouteStops WHERE Place_ID = " & cV2Q_String(FPL)
            rsStops.Open(strSQL, db)
            If rsStops.EOF Then
                FSeq = -1
            Else
                FSeq = rsStops.Fields("Seq").Value
            End If
            rsStops.Close()
            If FSeq <> -1 And BSeq <> -1 Then
                vSeq = (BSeq + FSeq) / 2
            ElseIf FSeq <> -1 Then
                vSeq = FSeq - 1
            ElseIf BSeq <> -1 Then
                vSeq = BSeq + 1
            End If
        ElseIf FPL <> "" Then
            strSQL = "SELECT Seq FROM dbo.tblRouteStops WHERE Place_ID = " & cV2Q_String(FPL)
            rsStops.Open(strSQL, db)
            If Not rsStops.EOF Then vSeq = rsStops.Fields("Seq").Value - 1
            rsStops.Close()
        ElseIf BPL <> "" Then
            strSQL = "SELECT Seq FROM dbo.tblRouteStops WHERE Place_ID = " & cV2Q_String(BPL)
            rsStops.Open(strSQL, db)
            If Not rsStops.EOF Then vSeq = rsStops.Fields("Seq").Value + 1
            rsStops.Close()
        End If
        FindSeq = vSeq
        rsStops = Nothing

    End Function

    Public Sub CleanSeq()

        db.Execute("TRUNCATE TABLE dbo.tblRouteStops")
    End Sub

    Public Sub RemoveRLZ()
        Dim rsDBF As ADODB.Recordset
        Dim rsRte As ADODB.Recordset
        Dim rsSeq As ADODB.Recordset
        Dim rs As ADODB.Recordset
        Dim rsCnt As ADODB.Recordset
        Dim strFile, strSQL, strPath As String
        Dim i, k, vRte As Integer
        Dim vDir, vDay As Integer
        Dim rte() As Integer
        Dim aRLZ As Array
        Dim ErrLog As Boolean
        Dim LogFile, strTmp As String

        On Error GoTo ErrHandler

        Me.lblMsg.Visible = True
        Me.lblMsg.Text = "Creating Layover Zone data...please be patient."

        strSQL = "DELETE dbo.tblTimepointSeq "
        strSQL = strSQL & "From dbo.tblTimepointSeq "
        strSQL = strSQL & "INNER Join  dbo.tblLayzTimePoint ON dbo.tblTimepointSeq.Route = dbo.tblLayzTimePoint.Route "
        strSQL = strSQL & "And dbo.tblTimepointSeq.Place_ID = dbo.tblLayzTimePoint.Place_ID "
        strSQL = strSQL & "And tblLayzTimePoint.Remote ='Y'"
        db.Execute(strSQL)

        strSQL = "DELETE dbo.tblMissingTimepoints "
        strSQL = strSQL & "From dbo.tblMissingTimepoints "
        strSQL = strSQL & "INNER Join  dbo.tblLayzTimePoint ON dbo.tblMissingTimepoints.Route = dbo.tblLayzTimePoint.Route "
        strSQL = strSQL & "And dbo.tblMissingTimepoints.Place = dbo.tblLayzTimePoint.Place_ID "
        strSQL = strSQL & "And tblLayzTimePoint.Remote ='Y'"
        db.Execute(strSQL)

        rsCnt = New ADODB.Recordset
        strSQL = "SELECT COUNT(*) As RecCount "
        strSQL = strSQL & "FROM (SELECT Route FROM dbo.tblTimepointSeq "
        strSQL = strSQL & "UNION ALL "
        strSQL = strSQL & "SELECT Route FROM dbo.tblMissingTimepoints M "
        strSQL = strSQL & "WHERE Not EXISTS "
        strSQL = strSQL & "(SELECT * FROM dbo.tblTimepointSeq WHERE Route=M.Route "
        strSQL = strSQL & "And Days=M.Days And Dir=M.Dir)) AS Temp "
        rsCnt.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockOptimistic, ADODB.CommandTypeEnum.adCmdText)
        k = CInt(rsCnt.Fields("RecCount").Value)
        rsCnt.Close()
        rsCnt = Nothing

        rsRte = New ADODB.Recordset
        strSQL = "(SELECT DISTINCT Route,Days,Dir FROM dbo.tblTimepointSeq)"
        strSQL = strSQL & " UNION (SELECT DISTINCT Route,Days,Dir FROM dbo.tblMissingTimepoints M"
        strSQL = strSQL & " WHERE NOT EXISTS (SELECT * FROM dbo.tblTimepointSeq WHERE Route=M.Route"
        strSQL = strSQL & " AND Days=M.Days AND Dir=M.Dir))"
        rsRte.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockOptimistic)

        If rsRte.EOF Then Exit Sub
        Me.ProgressBar1.Visible = True
        Me.ProgressBar1.Minimum = 0
        Me.ProgressBar1.Maximum = k
        Me.ProgressBar1.Value = 0
        Me.lblMsg.Text = "Finding Timepoint Sequence..."
        Me.lblMsg.Refresh()

        k = 0

        Do While Not rsRte.EOF
            Me.ProgressBar1.Value = Me.ProgressBar1.Value + 1

            vRte = rsRte.Fields("Route").Value
            vDay = rsRte.Fields("Days").Value
            vDir = rsRte.Fields("Dir").Value

            GetSeq(vRte, vDay, vDir)

            strSQL = "DELETE FROM dbo.tblTimepointSeq WHERE Route=" & vRte & " AND Dir=" & vDir & " AND Days=" & vDay
            db.Execute(strSQL)
            strSQL = "DELETE FROM dbo.tblMissingTimepoints WHERE Route=" & vRte & " AND Dir=" & vDir & " AND Days=" & vDay
            db.Execute(strSQL)

            rsSeq = New ADODB.Recordset
            strSQL = "Select * From dbo.tmpRouteStops"
            rsSeq.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockOptimistic, ADODB.CommandTypeEnum.adCmdText)
            If Not (rsSeq.EOF And rsSeq.BOF) Then
                rsSeq.MoveFirst()
                i = 0
                Do Until rsSeq.EOF
                    strSQL = "INSERT INTO dbo.tblTimepointSeq (Route,Dir,Place_ID,Seq,Days) VALUES ("
                    strSQL = strSQL & vRte & "," & vDir & "," & cV2Q_String(rsSeq.Fields("Place_ID").Value) & "," & i + 1 & "," & vDay & ")"
                    db.Execute(strSQL)
                    rsSeq.MoveNext()
                    i = i + 1
                Loop
            End If

            rsRte.MoveNext()
            k = k + 1
        Loop

        rsRte.Close()
        rsRte = Nothing

        'QA/QC
        ErrLog = False
        rs = New ADODB.Recordset

        Dim rst As ADODB.Recordset
        rst = New ADODB.Recordset
        strSQL = "SELECT * FROM dbo.tblLayzTimePoint WHERE Remote ='Y'"
        rst.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockOptimistic, ADODB.CommandTypeEnum.adCmdText)

        Me.ProgressBar1.Minimum = 0
        Me.ProgressBar1.Maximum = rst.RecordCount
        Me.ProgressBar1.Value = 0
        Me.lblMsg.Text = "QA/QC Timepoint Sequence..."
        Me.lblMsg.Refresh()

        If Not (rst.EOF And rst.BOF) Then
            rst.MoveFirst()
            i = 0
            Do Until rst.EOF
                Me.ProgressBar1.Value = i
                strSQL = "SELECT * FROM dbo.tblTimepointSeq WHERE Place_ID=" & cV2Q_String(rst.Fields("Place_ID").Value)
                strSQL = strSQL & " ORDER BY route,dir,days"
                rs.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockReadOnly)
                If Not rs.EOF And Not ErrLog Then
                    ErrLog = True
                    LogFile = VB6.GetPath & "\" & AppName & "_QAQC" & ".log"
                    FileOpen(1, LogFile, OpenMode.Output)
                End If
                Do While Not rs.EOF
                    strTmp = "Place ID: " & rs.Fields("Place_ID").Value & " in route: " & rs.Fields("Route").Value
                    strTmp = strTmp & ", Dir:" & rs.Fields("Dir").Value & ", Day: " & rs.Fields("Days").Value
                    strTmp = strTmp & " may be a Remote Layover Zone."
                    PrintLine(1, strTmp)
                    rs.MoveNext()
                Loop
                rs.Close()
                rst.MoveNext()
                i = i + 1
            Loop
        End If

        rst.Close()
        rst = Nothing

        strSQL = "SELECT * FROM dbo.tblTimepointSeq A WHERE NOT EXISTS"
        strSQL = strSQL & " (SELECT * FROM dbo.tblLandmarksAlias WHERE Place_ID=A.Place_ID)"
        strSQL = strSQL & " ORDER BY route,dir,days"
        rs.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockReadOnly)

        If Not rs.EOF And Not ErrLog Then
            ErrLog = True
            LogFile = VB6.GetPath & "\" & AppName & "_QAQC" & ".log"
            FileOpen(1, LogFile, OpenMode.Output)
        End If

        Do While Not rs.EOF
            strTmp = "Place ID: " & rs.Fields("Place_ID").Value & " in route: " & rs.Fields("Route").Value
            strTmp = strTmp & ", Dir:" & rs.Fields("Dir").Value & ", Day: " & rs.Fields("Days").Value
            strTmp = strTmp & " does not exist in Landmarks_alias table."
            PrintLine(1, strTmp)
            rs.MoveNext()
        Loop
        rs.Close()

        If ErrLog Then
            FileClose(1)
            If MsgBox("QA/QC Log Report generated. Please refer to log file " & LogFile & ".  Read log now?", MsgBoxStyle.YesNo + MsgBoxStyle.Question, "QA/QC Remote Layover Zones and Timepoint Names") = MsgBoxResult.Yes Then
                Shell("notepad.exe " & LogFile, AppWinStyle.NormalFocus)
            End If
        Else
            MsgBox("Remote Layover Zone timepoints have been removed and QA/QC with landmarks database has been done successfully.", MsgBoxStyle.Information, "Remote Layover Zone Timepoints and QA/QC")
        End If
        rs = Nothing

        Exit Sub
ErrHandler:
        db.Execute("TRUNCATE TABLE dbo.tblRouteStops")
        Err.Raise(Err.Number, Err.Source, Err.Description)

    End Sub

End Class