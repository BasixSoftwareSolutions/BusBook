Option Strict Off
Option Explicit On
Module ServChg
	Private oldFile As String
	Private newFile As String
	Private oldLandMFile As String
	Private newLandMFile As String
	
	Private cn As ADODB.Connection
	Private cn2 As ADODB.Connection
	Private rs As New ADODB.Recordset
	
	Sub ServiceChange(ByRef db1 As String, ByRef db2 As String, ByRef db3 As String, ByRef db4 As String)
		
		oldFile = db1
		newFile = db2
		oldLandMFile = db3
		newLandMFile = db4
		
		If oldFile = "" Or newFile = "" Or oldLandMFile = "" Or newLandMFile = "" Then
			MsgBox("MDB not set")
			GoTo dbNotSet
		Else
			cn = New ADODB.Connection
			cn.ConnectionString = "Provider=microsoft.jet.oledb.4.0;" & "Data Source=" & newFile
			
			cn.Open()
			On Error GoTo 0
			
			cn2 = New ADODB.Connection
			cn2.ConnectionString = "Provider=microsoft.jet.oledb.4.0;" & "Data Source=" & newLandMFile
			
			cn2.Open()
			On Error GoTo 0
			
		End If
		
		StartComparing()
		
		cn.Close()
		cn2.Close()
        cn = Nothing
        cn2 = Nothing
dbNotSet: 
	End Sub
	
	Public Sub StartComparing()
		If CheckExisting = True Then
			DropOutputTable()
		End If
		
		CreateOutputTable()
		
		cmpRte()
		cmpDir()
		cmpDay()
		cmpSeq() ' timepoint squence
		cmpTpPlaceID() 'compare TP placeid
		cmpTpName() 'compare TP description landmark mdb, landmark_alias table, alias field
		cmpLandmark() 'landmark mdb actual desciption of Route
		cmpTripNum()
		cmpTime()
		
	End Sub
	Public Sub DropOutputTable()
		Dim strSQL As String
		strSQL = "drop table QAQC_Log"
		cn.Execute(strSQL)
	End Sub
	
	Public Sub CreateOutputTable()
		Dim strSQL As String
		
		strSQL = "create table QAQC_Log (Route integer, Dir integer, Days integer, Differences varchar(50))"
		cn.Execute(strSQL)
	End Sub
	
	Public Function CheckExisting() As Boolean
		Dim b As Boolean
		b = False
		
		rs = cn.OpenSchema(ADODB.SchemaEnum.adSchemaTables)
		Do While Not rs.EOF
			If Left(rs.Fields("Table_Name").Value, 4) <> "MSys" And Left(rs.Fields("Table_Name").Value, 4) <> "USys" Then
				If rs.Fields("Table_Type").Value <> "VIEW" Then
					If UCase(rs.Fields("Table_Name").Value) = "QAQC_LOG" Then
						b = True
					End If
				End If
			End If
			rs.MoveNext()
		Loop 
		
		rs.Close()
        rs = Nothing
        CheckExisting = b
	End Function
	
	
	'***************************************************************************************
	'Start Comaring ************************************************************************
	'***************************************************************************************
	
	Public Sub cmpRte()
		Dim strSQL As Object

        strSQL = "SELECT distinct A.route, B.route FROM " & "[timepoint_seq] A left join (select * from [timepoint_seq] IN " & "'" & oldFile & "') B " & "on B.route = A.route where B.route is null"
        rs.Open(strSQL, cn)
		
		While Not rs.EOF
            strSQL = "INSERT INTO QAQC_Log VALUES (" & rs.Fields("A.route").Value & ", -1, -1, 'New route')"
            cn.Execute(strSQL)
            rs.MoveNext()
		End While
		rs.Close()

        strSQL = "SELECT distinct A.route, B.route FROM " & "[timepoint_seq] A right join (select * from [timepoint_seq] IN " & "'" & oldFile & "') B " & "on B.route = A.route where A.route is null "
        rs.Open(strSQL, cn)
		
		While Not rs.EOF
            strSQL = "INSERT INTO QAQC_Log VALUES (" & rs.Fields("B.route").Value & ", -1, -1, 'Discontinued route')"
            cn.Execute(strSQL)
            rs.MoveNext()
		End While
		rs.Close()
	End Sub
	
	Sub cmpDir()
		Dim strSQL As Object

        strSQL = "SELECT distinct A.route FROM " & "[timepoint_seq] A left join (select * from [timepoint_seq] IN " & "'" & oldFile & "') B " & "on A.route = B.route and A.dir = B.dir where B.dir is null"
        rs.Open(strSQL, cn)
		
		While Not rs.EOF
            strSQL = "INSERT INTO QAQC_Log VALUES (" & rs.Fields("route").Value & ", -1, -1, 'Direction different in heading')"
            cn.Execute(strSQL)
            rs.MoveNext()
		End While
		rs.Close()

        strSQL = "SELECT distinct B.route FROM " & "[timepoint_seq] A right join (select * from [timepoint_seq] IN " & "'" & oldFile & "') B " & "on A.route = B.route and A.dir = B.dir where A.dir is null"
        rs.Open(strSQL, cn)
		
		While Not rs.EOF
            strSQL = "INSERT INTO QAQC_Log VALUES (" & rs.Fields("route").Value & ", -1, -1, 'Direction different in heading')"
            cn.Execute(strSQL)
            rs.MoveNext()
		End While
		rs.Close()
		
	End Sub
	
	Sub cmpDay()
		Dim strSQL As Object

        strSQL = "SELECT distinct A.route, A.dir FROM " & "[timepoint_seq] A left join (select * from [timepoint_seq] IN " & "'" & oldFile & "') B " & "on A.route = B.route and A.dir = B.dir and A.days = B.days where B.days is null"
        rs.Open(strSQL, cn)
		
		While Not rs.EOF
            strSQL = "INSERT INTO QAQC_Log VALUES (" & rs.Fields("route").Value & "," & rs.Fields("dir").Value & ", -1, 'Day different in heading')"
            cn.Execute(strSQL)
            rs.MoveNext()
		End While
		rs.Close()

        strSQL = "SELECT distinct B.route, B.dir FROM " & "[timepoint_seq] A right join (select * from [timepoint_seq] IN " & "'" & oldFile & "') B " & "on A.route = B.route and A.dir = B.dir and A.days = B.days where A.days is null"
        rs.Open(strSQL, cn)
		
		While Not rs.EOF
            strSQL = "INSERT INTO QAQC_Log VALUES (" & rs.Fields("route").Value & "," & rs.Fields("dir").Value & ", -1, 'Day different in heading')"
            cn.Execute(strSQL)
            rs.MoveNext()
		End While
		rs.Close()
		
	End Sub
	
	Sub cmpSeq()
		Dim strSQL As Object 'gets time point sequence

        strSQL = "SELECT distinct A.Route, A.Dir, A.Days " & " FROM [timepoint_seq] A LEFT JOIN (select * from [timepoint_seq] in '" & oldFile & "') B ON (A.Route = B.Route) AND (A.Dir = B.Dir) AND (A.Place_ID = B.Place_ID) AND (A.Seq = B.Seq) AND (A.Days = B.Days) " & " WHERE (((B.Route) Is Null) AND ((B.Dir) Is Null) AND ((B.Days) Is Null)); "

        rs.Open(strSQL, cn)
		While Not rs.EOF
            strSQL = "INSERT INTO QAQC_Log VALUES (" & rs.Fields("route").Value & "," & rs.Fields("dir").Value & "," & rs.Fields("days").Value & ", 'Timepoint sequence not matching')"
            cn.Execute(strSQL)
            rs.MoveNext()
		End While
		rs.Close()
		
	End Sub
	
	Sub cmpTpPlaceID()
		Dim strSQL As Object 'this checks TP place id change

        strSQL = "SELECT distinct A.route, A.dir, A.days FROM " & "[timepoint_seq] A left join (select * from [timepoint_seq] IN '" & oldFile & "') B " & "on A.route = B.route and A.dir = B.dir and A.days = B.days and A.place_id = B.place_id where B.place_id is null"

        rs.Open(strSQL, cn)
		
		While Not rs.EOF
            strSQL = "INSERT INTO QAQC_Log VALUES (" & rs.Fields("route").Value & "," & rs.Fields("dir").Value & "," & rs.Fields("days").Value & ", 'Timepoint name not matching')"
            cn.Execute(strSQL)
            rs.MoveNext()
		End While
		rs.Close()
	End Sub
	
	Public Sub cmpTpName()
		Dim strSQL As Object

        'a= passing time
        'b = new landmarks
        'c = old landmarks

        strSQL = "SELECT A.Route_ID, A.Days, A.Direction, B.PLACE_ID, B.ALIAS " & " FROM [GIS Passing Times] A INNER JOIN (( select * from [Landmarks_alias] IN '" & newLandMFile & "') B LEFT JOIN " & " (select * from [Landmarks_alias] IN '" & oldLandMFile & "' ) C ON (B.ALIAS = C.ALIAS) AND (B.PLACE_ID = C.PLACE_ID)) ON A.Place_ID = B.PLACE_ID " & " GROUP BY A.Route_ID, A.Days, A.Direction, C.PLACE_ID, C.ALIAS, B.PLACE_ID, B.ALIAS " & " HAVING (((C.PLACE_ID) Is Null) AND ((C.ALIAS) Is Null)); "

        'Debug.Print strSQL

        rs.Open(strSQL, cn)
		
		While Not rs.EOF
            strSQL = "INSERT INTO QAQC_Log VALUES (" & rs.Fields("route_ID").Value & "," & rs.Fields("direction").Value & "," & rs.Fields("days").Value & ", 'Timepoint name not matching')"
            cn.Execute(strSQL)
            rs.MoveNext()
		End While
		rs.Close()
		
		
	End Sub
	
	
	Sub cmpLandmark()
		Dim strSQL As Object
        Dim dir_Renamed As Short
        strSQL = "SELECT distinct A.route, A.direction, A.days FROM " & "[Bus Route Descriptions] A left join (select * from [Bus Route Descriptions] IN " & "'" & oldLandMFile & "') B " & "on A.route = B.route and A.direction = B.direction and A.days = B.days and A.[to:] = B.[to:] " & "where B.[to:] is null"

        rs.Open(strSQL, cn2)
		
		While Not rs.EOF
			If rs.Fields("direction").Value = "North" Then
				dir_Renamed = 0
			ElseIf rs.Fields("direction").Value = "South" Then 
				dir_Renamed = 1
			ElseIf rs.Fields("direction").Value = "East" Then 
				dir_Renamed = 2
			ElseIf rs.Fields("direction").Value = "West" Then 
				dir_Renamed = 3
			ElseIf rs.Fields("direction").Value = "Clockwise" Then 
				dir_Renamed = 4
			ElseIf rs.Fields("direction").Value = "Counterclockwise" Then 
				dir_Renamed = 5
			End If

            strSQL = "INSERT INTO QAQC_Log VALUES (" & rs.Fields("route").Value & "," & dir_Renamed & "," & rs.Fields("days").Value & ", 'Bus Route Description not matching')"

            cn.Execute(strSQL)
            rs.MoveNext()
		End While
		rs.Close()
	End Sub
	
	Sub cmpTripNum()
		Dim strSQL As Object
        strSQL = "SELECT distinct A.cnt, A.route_id, A.direction, A.days FROM " & "(SELECT count(*) as [cnt], route_id, direction, days FROM (select distinct " & "route_id, direction, days, trip_id FROM [GIS Passing Times]) GROUP BY route_id, " & "direction,days) A LEFT JOIN (SELECT count(*) as [cnt], route_id, direction,days " & "FROM (SELECT distinct route_id, direction, days, trip_id FROM [GIS Passing Times] IN " & "'" & oldFile & "') GROUP BY route_id, direction, days) B ON (A.cnt = B.cnt) and " & "(A.route_id = B.route_id) and (A.direction = B.direction) and (A.days = B.days) where " & "B.cnt is null"

        rs.Open(strSQL, cn)
		
		If Not rs.EOF Then 'added by cameron
			rs.MoveFirst()
		End If ' end addition
		
		While Not rs.EOF
            strSQL = "INSERT INTO QAQC_Log VALUES (" & rs.Fields("route_id").Value & "," & CShort(rs.Fields("direction").Value) & "," & rs.Fields("days").Value & ", 'Number of trips not matching')"
            cn.Execute(strSQL)
            rs.MoveNext()
		End While
		rs.Close()
		
	End Sub
	
	Sub cmpTime()
		Dim strSQL As Object

        strSQL = "SELECT distinct A.route_id, A.direction, A.days FROM " & "[GIS Passing Times] A left join (select * from [GIS Passing Times] IN " & "'" & oldFile & "') B " & "on A.route_id = B.route_id and A.direction = B.direction and " & "A.days = B.days and A.time = B.time where B.time is null"
        rs.Open(strSQL, cn)
		
		While Not rs.EOF
            strSQL = "INSERT INTO QAQC_Log VALUES (" & rs.Fields("route_id").Value & "," & rs.Fields("direction").Value & "," & rs.Fields("days").Value & ", 'Time not matching')"
            cn.Execute(strSQL)
            rs.MoveNext()
		End While
		rs.Close()
	End Sub
End Module