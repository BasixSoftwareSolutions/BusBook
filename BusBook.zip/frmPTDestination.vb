Option Strict Off
Option Explicit On
Imports System.IO
Imports System.Data.SqlClient

Friend Class frmPTDestination
    Inherits System.Windows.Forms.Form
#Region "Windows Form Designer generated code "
    Public Sub New()
        MyBase.New()
        If m_vb6FormDefInstance Is Nothing Then
            If m_InitializingDefInstance Then
                m_vb6FormDefInstance = Me
            Else
                Try
                    'For the start-up form, the first instance created is the default instance.
                    If System.Reflection.Assembly.GetExecutingAssembly.EntryPoint.DeclaringType Is Me.GetType Then
                        m_vb6FormDefInstance = Me
                    End If
                Catch
                End Try
            End If
        End If
        'This call is required by the Windows Form Designer.
        InitializeComponent()
    End Sub
    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
        If Disposing Then
            If Not components Is Nothing Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(Disposing)
    End Sub
    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer
    Public ToolTip1 As System.Windows.Forms.ToolTip
    Public WithEvents cmdImport As System.Windows.Forms.Button
    Public WithEvents lblMsg As System.Windows.Forms.Label
    Friend WithEvents txtGISPassTimesFile As TextBox
    Public WithEvents Label1 As Label
    Friend WithEvents ProgressBar1 As ProgressBar
    Friend WithEvents OpenFileDialog1 As OpenFileDialog
    Friend WithEvents sqlBBConn As SqlConnection
    Friend WithEvents cmdGetFile As Button
    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmPTDestination))
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.cmdImport = New System.Windows.Forms.Button()
        Me.lblMsg = New System.Windows.Forms.Label()
        Me.txtGISPassTimesFile = New System.Windows.Forms.TextBox()
        Me.cmdGetFile = New System.Windows.Forms.Button()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.ProgressBar1 = New System.Windows.Forms.ProgressBar()
        Me.OpenFileDialog1 = New System.Windows.Forms.OpenFileDialog()
        Me.sqlBBConn = New System.Data.SqlClient.SqlConnection()
        Me.SuspendLayout()
        '
        'cmdImport
        '
        Me.cmdImport.BackColor = System.Drawing.SystemColors.Control
        Me.cmdImport.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdImport.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdImport.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdImport.Location = New System.Drawing.Point(100, 199)
        Me.cmdImport.Name = "cmdImport"
        Me.cmdImport.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdImport.Size = New System.Drawing.Size(185, 33)
        Me.cmdImport.TabIndex = 10
        Me.cmdImport.Text = "&Import"
        Me.cmdImport.UseVisualStyleBackColor = False
        Me.cmdImport.Visible = False
        '
        'lblMsg
        '
        Me.lblMsg.BackColor = System.Drawing.Color.Transparent
        Me.lblMsg.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblMsg.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblMsg.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.lblMsg.Location = New System.Drawing.Point(17, 304)
        Me.lblMsg.Name = "lblMsg"
        Me.lblMsg.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblMsg.Size = New System.Drawing.Size(346, 25)
        Me.lblMsg.TabIndex = 12
        '
        'txtGISPassTimesFile
        '
        Me.txtGISPassTimesFile.Font = New System.Drawing.Font("Verdana", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.txtGISPassTimesFile.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.txtGISPassTimesFile.Location = New System.Drawing.Point(20, 147)
        Me.txtGISPassTimesFile.Name = "txtGISPassTimesFile"
        Me.txtGISPassTimesFile.Size = New System.Drawing.Size(348, 20)
        Me.txtGISPassTimesFile.TabIndex = 13
        Me.txtGISPassTimesFile.Visible = False
        '
        'cmdGetFile
        '
        Me.cmdGetFile.BackColor = System.Drawing.SystemColors.Control
        Me.cmdGetFile.Font = New System.Drawing.Font("Verdana", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdGetFile.Location = New System.Drawing.Point(100, 100)
        Me.cmdGetFile.Name = "cmdGetFile"
        Me.cmdGetFile.Size = New System.Drawing.Size(185, 33)
        Me.cmdGetFile.TabIndex = 14
        Me.cmdGetFile.Text = "Select GIS Pass Times File"
        Me.cmdGetFile.UseVisualStyleBackColor = False
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label1.Font = New System.Drawing.Font("Verdana", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.Gray
        Me.Label1.Location = New System.Drawing.Point(20, 15)
        Me.Label1.Name = "Label1"
        Me.Label1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label1.Size = New System.Drawing.Size(329, 25)
        Me.Label1.TabIndex = 15
        Me.Label1.Text = "IMPORT GIS PASSING TIMES"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'ProgressBar1
        '
        Me.ProgressBar1.Location = New System.Drawing.Point(20, 278)
        Me.ProgressBar1.MarqueeAnimationSpeed = 60
        Me.ProgressBar1.Name = "ProgressBar1"
        Me.ProgressBar1.Size = New System.Drawing.Size(343, 23)
        Me.ProgressBar1.Style = System.Windows.Forms.ProgressBarStyle.Marquee
        Me.ProgressBar1.TabIndex = 16
        Me.ProgressBar1.Visible = False
        '
        'OpenFileDialog1
        '
        Me.OpenFileDialog1.FileName = "OpenFileDialog1"
        '
        'sqlBBConn
        '
        Me.sqlBBConn.ConnectionString = "Data Source=ORMSQL24;Initial Catalog=BusBook;Persist Security Info=True;User ID=I" &
    "nHouseApp_User;Password=Oct@!2345"
        Me.sqlBBConn.FireInfoMessageEventOnUserErrors = False
        '
        'frmPTDestination
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(375, 375)
        Me.Controls.Add(Me.ProgressBar1)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.cmdGetFile)
        Me.Controls.Add(Me.txtGISPassTimesFile)
        Me.Controls.Add(Me.cmdImport)
        Me.Controls.Add(Me.lblMsg)
        Me.Cursor = System.Windows.Forms.Cursors.Default
        Me.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Location = New System.Drawing.Point(411, 311)
        Me.Name = "frmPTDestination"
        Me.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
#End Region
#Region "Upgrade Support "
    Private Shared m_vb6FormDefInstance As frmPTDestination
    Private Shared m_InitializingDefInstance As Boolean
    Public Shared Property DefInstance() As frmPTDestination
        Get
            If m_vb6FormDefInstance Is Nothing OrElse m_vb6FormDefInstance.IsDisposed Then
                m_InitializingDefInstance = True
                m_vb6FormDefInstance = New frmPTDestination()
                m_InitializingDefInstance = False
            End If
            DefInstance = m_vb6FormDefInstance
        End Get
        Set
            m_vb6FormDefInstance = Value
        End Set
    End Property
#End Region

    Dim cnnMDB As ADODB.Connection
    Public ptTXTFile As String

    Private Sub SQLBulkCopy()

        Dim dt As New DataTable()
        Dim line As String = Nothing
        Dim i As Integer = 0

        Using sr As StreamReader = File.OpenText(ptTXTFile)
            line = sr.ReadLine()
            Do While line IsNot Nothing
                Dim data() As String = line.Split(";"c)
                If data.Length > 0 Then
                    If i = 0 Then
                        For k As Integer = 0 To data.Length() - 1
                            dt.Columns.Add(New DataColumn())
                        Next
                        i += 1
                    End If
                    Dim row As DataRow = dt.NewRow()
                    row.ItemArray = data
                    dt.Rows.Add(row)
                End If
                line = sr.ReadLine()
            Loop
        End Using

        db.Execute("TRUNCATE TABLE dbo.tmpGISPassingTimes")

        Dim cn As New SqlClient.SqlConnection(sConn)
        Dim cmd As New SqlCommand()
        cmd.Connection = cn
        cn.Open()

        Using copy As New SqlBulkCopy(cn)
            copy.ColumnMappings.Add(0, 0)
            copy.ColumnMappings.Add(1, 1)
            copy.ColumnMappings.Add(2, 2)
            copy.ColumnMappings.Add(3, 3)
            copy.ColumnMappings.Add(4, 4)
            copy.ColumnMappings.Add(5, 5)
            copy.ColumnMappings.Add(6, 6)
            copy.ColumnMappings.Add(7, 7)
            copy.ColumnMappings.Add(8, 8)
            copy.ColumnMappings.Add(9, 9)
            copy.ColumnMappings.Add(10, 10)
            copy.ColumnMappings.Add(11, 11)
            copy.DestinationTableName = "dbo.tmpGISPassingTimes"
            copy.WriteToServer(dt)
        End Using

        db.Execute("spAppendGISPassingTimes")


    End Sub
    Private Sub GetPassingTimeFile()

        OpenFileDialog1.Title = "Please select a GIS Passtimes file"
        OpenFileDialog1.InitialDirectory = "C:\BusBook.NET"
        OpenFileDialog1.Filter = "Text Files|*.txt"

        If (OpenFileDialog1.ShowDialog() = DialogResult.OK) Then
            txtGISPassTimesFile.Visible = True
            txtGISPassTimesFile.Text = OpenFileDialog1.FileName
            ptTXTFile = OpenFileDialog1.FileName
        End If

        Exit Sub

lblCancel:
        If Err.Number = cdlCancel Then
            'Cancel
        Else
            MsgBox("Cannot open data file." & vbCrLf & Err.Description & "", MsgBoxStyle.Exclamation, "Create Time Tables")
        End If
        Exit Sub
    End Sub

    Private Function cdlCancel() As Integer
        Throw New NotImplementedException()
    End Function

    Private Sub cmdImport_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdImport.Click
        Dim cnnTXT As ADODB.Connection
        Dim fso As New Scripting.FileSystemObject
        Dim ptFName, strSQL, ptFPath As String
        Dim rs As New ADODB.Recordset
        Dim vDir, vDay, vInput As Object
        Dim InputData() As Object
        Dim InputStr As String
        Dim vCnt As Integer

        On Error GoTo ErrHandler

        If MsgBox("Import and Process GIS Pass Time File?", MsgBoxStyle.YesNo + MsgBoxStyle.Question, AppTitle) = MsgBoxResult.No Then
            Exit Sub
        End If

        If ptTXTFile = "" Then
            MsgBox("Please select a GIS Passing Times file first.", MsgBoxStyle.Critical, "Select File")
            Exit Sub
        End If

        lblMsg.Visible = True
        lblMsg.Text = "Importing data..."

        Call SQLBulkCopy()

        FindTPSeq()
        ProgressBar1.Visible = False
        lblMsg.Visible = False
        Me.Cursor = System.Windows.Forms.Cursors.Default
        MsgBox("Process completed.", MsgBoxStyle.Information, "Import Status")
        Exit Sub
ErrHandler:
        Me.Cursor = System.Windows.Forms.Cursors.Default
        FileClose(1)
        MsgBox(Err.Source & ": " & Err.Description, MsgBoxStyle.Exclamation, AppTitle)
        Resume Next
    End Sub

    Private Sub FindTPSeq()
        On Error Resume Next

        Dim rs As New ADODB.Recordset
        Dim rsTP As New ADODB.Recordset
        Dim vFPl, strSQL, vBPl As String
        Dim vTrip, vDay, vRte, vDir, vPlace As Object
        Dim vSeq As Integer
        Dim i As Integer

        strSQL = "TRUNCATE TABLE dbo.tblPTTrips"
        db.Execute(strSQL)
        strSQL = "INSERT INTO tblPTTrips SELECT Route_ID,Days,Direction,Trip_ID,COUNT(*) as cnt FROM dbo.tblGISPassingTimes"
        strSQL = strSQL & " GROUP BY Route_ID,Days,Direction,Trip_ID"
        db.Execute(strSQL)
        strSQL = "TRUNCATE TABLE dbo.tblTimepointSeq"
        db.Execute(strSQL)
        strSQL = "SELECT * FROM tblPTTrips ORDER BY Route_ID,Days,Direction,Cnt desc"
        rs.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockReadOnly)
        vRte = -1
        vDir = -1
        vDay = -1

        ProgressBar1.Minimum = 0
        ProgressBar1.Maximum = rs.RecordCount
        ProgressBar1.Value = 0
        ProgressBar1.Visible = True
        lblMsg.Text = "Creating Time Point Sequence..."
        Me.Refresh()
        i = 0

        Do While Not rs.EOF
            ProgressBar1.Value = IIf(i < 0 Or i > ProgressBar1.Maximum, ProgressBar1.Maximum, i)
            If rs.Fields("Route_ID").Value <> vRte Or rs.Fields("Days").Value <> vDay Or rs.Fields("Direction").Value <> vDir Then
                vRte = IIf(Convert.IsDBNull(rs.Fields("Route_ID").Value), -1, rs.Fields("Route_ID").Value)
                vDay = IIf(Convert.IsDBNull(rs.Fields("Days").Value), -1, rs.Fields("Days").Value)
                vDir = FilterNull((rs.Fields("Direction").Value))
                vTrip = FilterNull((rs.Fields("Trip_ID").Value))
                vSeq = 10
                strSQL = "SELECT Place_ID FROM dbo.tblGISPassingTimes WHERE Route_ID=" & vRte
                strSQL = strSQL & " AND Days=" & vDay & " AND Direction=" & cV2Q_String(vDir)
                strSQL = strSQL & " AND Trip_ID=" & cV2Q_String(vTrip) & " ORDER BY [Time]"
                rsTP.Open(strSQL, db)
                Do While Not rsTP.EOF
                    strSQL = "INSERT INTO tblTimepointSeq (Route,Dir,Place_ID,Seq,Days) VALUES ("
                    strSQL = strSQL & vRte & "," & vDir & "," & cV2Q_String((rsTP.Fields("Place_ID").Value)) & "," & vSeq & "," & vDay & ")"
                    db.Execute(strSQL)
                    vSeq = vSeq + 10
                    rsTP.MoveNext()
                Loop
                rsTP.Close()
            End If
            rs.MoveNext()
            i = i + 1
        Loop
        rs.Close()

        strSQL = "TRUNCATE TABLE dbo.tblMissingTimepoints"
        db.Execute(strSQL)
        strSQL = "SELECT Trip_ID,Route_ID,Days,Direction,Place_ID FROM tblGISPassingTimes AS A WHERE NOT EXISTS "
        strSQL = strSQL & "(SELECT * FROM tblTimepointSeq WHERE Place_ID=A.Place_ID AND Route=A.Route_ID"
        strSQL = strSQL & " AND Days=A.Days AND STR(Dir)=STR(A.Direction)) ORDER BY Route_ID,Days,Direction,Place_ID"
        rs.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockReadOnly)
        vRte = -1
        vDir = -1
        vDay = -1
        vPlace = ""

        ProgressBar1.Minimum = 0
        ProgressBar1.Maximum = rs.RecordCount
        ProgressBar1.Value = 0
        ProgressBar1.Visible = True
        lblMsg.Text = "Fixing Missing Time Points..."
        Me.Refresh()
        i = 0

        Do While Not rs.EOF
            ProgressBar1.Value = IIf(i < 0 Or i > ProgressBar1.Maximum, ProgressBar1.Maximum, i)
            If rs.Fields("Route_ID").Value <> vRte Or rs.Fields("Days").Value <> vDay Or rs.Fields("Direction").Value <> vDir Or rs.Fields("Place_ID").Value <> vPlace Then
                vTrip = FilterNull((rs.Fields("Trip_ID").Value))
                vRte = IIf(IsDBNull(rs.Fields("Route_ID").Value), -1, rs.Fields("Route_ID").Value)
                vDay = IIf(IsDBNull(rs.Fields("Days").Value), -1, rs.Fields("Days").Value)
                vDir = FilterNull((rs.Fields("Direction").Value))
                vPlace = FilterNull((rs.Fields("Place_ID").Value))
                vFPl = "" : vBPl = ""
                strSQL = "SELECT Place_ID FROM tblGISPassingTimes WHERE Route_ID=" & vRte
                strSQL = strSQL & " AND Days=" & vDay & " AND Direction=" & cV2Q_String(vDir)
                strSQL = strSQL & " AND Trip_ID=" & cV2Q_String(vTrip) & " ORDER BY [Time]"
                rsTP.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockReadOnly)
                Do While Not rsTP.EOF
                    If rsTP.Fields("Place_ID").Value = vPlace Then
                        rsTP.MoveNext()
                        If Not rsTP.EOF Then
                            vFPl = rsTP.Fields("Place_ID").Value
                            Exit Do
                        End If
                    Else
                        vBPl = rsTP.Fields("Place_ID").Value
                        rsTP.MoveNext()
                    End If
                Loop
                rsTP.Close()
                strSQL = "INSERT INTO dbo.tblMissingTimepoints (Route,Dir,Place,Back_Place,Forward_Pl,Days) VALUES ("
                strSQL = strSQL & vRte & "," & vDir & "," & cV2Q_String(vPlace) & ","
                strSQL = strSQL & cV2Q_String(vBPl) & "," & cV2Q_String(vFPl) & "," & vDay & ")"
                db.Execute(strSQL)
            End If
            rs.MoveNext()
            i = i + 1
        Loop
        rs.Close()
        rs = Nothing
        rsTP = Nothing

    End Sub

    Private Sub cmdGetFile_Click(sender As Object, e As EventArgs) Handles cmdGetFile.Click

        GetPassingTimeFile()
        Me.txtGISPassTimesFile.Visible = True
        Me.cmdImport.Visible = True

    End Sub
End Class