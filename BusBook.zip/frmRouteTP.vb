Option Strict Off
Option Explicit On
Friend Class frmRouteTP
	Inherits System.Windows.Forms.Form
#Region "Windows Form Designer generated code "
	Public Sub New()
		MyBase.New()
		If m_vb6FormDefInstance Is Nothing Then
			If m_InitializingDefInstance Then
				m_vb6FormDefInstance = Me
			Else
				Try 
					'For the start-up form, the first instance created is the default instance.
					If System.Reflection.Assembly.GetExecutingAssembly.EntryPoint.DeclaringType Is Me.GetType Then
						m_vb6FormDefInstance = Me
					End If
				Catch
				End Try
			End If
		End If
		'This call is required by the Windows Form Designer.
		InitializeComponent()
	End Sub
	'Form overrides dispose to clean up the component list.
	Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
		If Disposing Then
			If Not components Is Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(Disposing)
	End Sub
	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer
	Public ToolTip1 As System.Windows.Forms.ToolTip
    Friend WithEvents tdbgRT As DataGridView
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents BusBookDataSet As BusBookDataSet
    Friend WithEvents VwTimePointSequenceBindingSource As BindingSource
    Friend WithEvents VwTimePointSequenceTableAdapter As BusBookDataSetTableAdapters.vwTimePointSequenceTableAdapter
    Friend WithEvents RouteIDDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents DaysDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents DirectionDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents TimePointSeq As TimePointSeq
    Friend WithEvents TblTimepointSeqBindingSource As BindingSource
    Friend WithEvents TblTimepointSeqTableAdapter As TimePointSeqTableAdapters.tblTimepointSeqTableAdapter
    Friend WithEvents Label1 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label5 As Label
    Friend WithEvents Label6 As Label
    Friend WithEvents Label7 As Label
    Friend WithEvents Label8 As Label
    Friend WithEvents Label9 As Label
    Friend WithEvents Label10 As Label
    Friend WithEvents Label11 As Label
    Friend WithEvents cmdMoveUp As Button
    Friend WithEvents cmdMoveDown As Button
    Friend WithEvents cmSave As Button
    Friend WithEvents PlaceIDDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents SeqDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents RouteDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents DirDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents DaysDataGridViewTextBoxColumn1 As DataGridViewTextBoxColumn
    Public WithEvents lblFormTitle As System.Windows.Forms.Label
    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        'Dim DataGridView1 As System.Windows.Forms.DataGridView
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle6 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle7 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmRouteTP))
        Me.PlaceIDDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.SeqDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.RouteDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DirDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DaysDataGridViewTextBoxColumn1 = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TblTimepointSeqBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.TimePointSeq = New BusBook.TimePointSeq()
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.lblFormTitle = New System.Windows.Forms.Label()
        Me.tdbgRT = New System.Windows.Forms.DataGridView()
        Me.RouteIDDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DaysDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DirectionDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.VwTimePointSequenceBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.BusBookDataSet = New BusBook.BusBookDataSet()
        Me.VwTimePointSequenceTableAdapter = New BusBook.BusBookDataSetTableAdapters.vwTimePointSequenceTableAdapter()
        Me.TblTimepointSeqTableAdapter = New BusBook.TimePointSeqTableAdapters.tblTimepointSeqTableAdapter()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label5 = New System.Windows.Forms.Label()
        Me.Label6 = New System.Windows.Forms.Label()
        Me.Label7 = New System.Windows.Forms.Label()
        Me.Label8 = New System.Windows.Forms.Label()
        Me.Label9 = New System.Windows.Forms.Label()
        Me.Label10 = New System.Windows.Forms.Label()
        Me.Label11 = New System.Windows.Forms.Label()
        Me.cmdMoveUp = New System.Windows.Forms.Button()
        Me.cmdMoveDown = New System.Windows.Forms.Button()
        Me.cmSave = New System.Windows.Forms.Button()
        DataGridView1 = New System.Windows.Forms.DataGridView()
        CType(DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblTimepointSeqBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TimePointSeq, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.tdbgRT, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.VwTimePointSequenceBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BusBookDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'DataGridView1
        '
        DataGridView1.AllowUserToAddRows = False
        DataGridView1.AllowUserToDeleteRows = False
        DataGridView1.AllowUserToOrderColumns = True
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.LightYellow
        DataGridView1.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle1
        DataGridView1.AutoGenerateColumns = False
        DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.PlaceIDDataGridViewTextBoxColumn, Me.SeqDataGridViewTextBoxColumn, Me.RouteDataGridViewTextBoxColumn, Me.DirDataGridViewTextBoxColumn, Me.DaysDataGridViewTextBoxColumn1})
        DataGridView1.DataSource = Me.TblTimepointSeqBindingSource
        DataGridView1.Location = New System.Drawing.Point(368, 56)
        DataGridView1.MultiSelect = False
        DataGridView1.Name = "DataGridView1"
        DataGridView1.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        DataGridView1.Size = New System.Drawing.Size(218, 530)
        DataGridView1.TabIndex = 34
        '
        'PlaceIDDataGridViewTextBoxColumn
        '
        Me.PlaceIDDataGridViewTextBoxColumn.DataPropertyName = "Place_ID"
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.PlaceIDDataGridViewTextBoxColumn.DefaultCellStyle = DataGridViewCellStyle2
        Me.PlaceIDDataGridViewTextBoxColumn.HeaderText = "Place ID"
        Me.PlaceIDDataGridViewTextBoxColumn.Name = "PlaceIDDataGridViewTextBoxColumn"
        Me.PlaceIDDataGridViewTextBoxColumn.ReadOnly = True
        '
        'SeqDataGridViewTextBoxColumn
        '
        Me.SeqDataGridViewTextBoxColumn.DataPropertyName = "Seq"
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.SeqDataGridViewTextBoxColumn.DefaultCellStyle = DataGridViewCellStyle3
        Me.SeqDataGridViewTextBoxColumn.HeaderText = "Sequence"
        Me.SeqDataGridViewTextBoxColumn.Name = "SeqDataGridViewTextBoxColumn"
        Me.SeqDataGridViewTextBoxColumn.Width = 75
        '
        'RouteDataGridViewTextBoxColumn
        '
        Me.RouteDataGridViewTextBoxColumn.DataPropertyName = "Route"
        Me.RouteDataGridViewTextBoxColumn.HeaderText = "Route"
        Me.RouteDataGridViewTextBoxColumn.Name = "RouteDataGridViewTextBoxColumn"
        Me.RouteDataGridViewTextBoxColumn.Visible = False
        '
        'DirDataGridViewTextBoxColumn
        '
        Me.DirDataGridViewTextBoxColumn.DataPropertyName = "Dir"
        Me.DirDataGridViewTextBoxColumn.HeaderText = "Dir"
        Me.DirDataGridViewTextBoxColumn.Name = "DirDataGridViewTextBoxColumn"
        Me.DirDataGridViewTextBoxColumn.Visible = False
        '
        'DaysDataGridViewTextBoxColumn1
        '
        Me.DaysDataGridViewTextBoxColumn1.DataPropertyName = "Days"
        Me.DaysDataGridViewTextBoxColumn1.HeaderText = "Days"
        Me.DaysDataGridViewTextBoxColumn1.Name = "DaysDataGridViewTextBoxColumn1"
        Me.DaysDataGridViewTextBoxColumn1.Visible = False
        '
        'TblTimepointSeqBindingSource
        '
        Me.TblTimepointSeqBindingSource.DataMember = "tblTimepointSeq"
        Me.TblTimepointSeqBindingSource.DataSource = Me.TimePointSeq
        '
        'TimePointSeq
        '
        Me.TimePointSeq.DataSetName = "TimePointSeq"
        Me.TimePointSeq.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'lblFormTitle
        '
        Me.lblFormTitle.BackColor = System.Drawing.Color.Transparent
        Me.lblFormTitle.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblFormTitle.Font = New System.Drawing.Font("Verdana", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFormTitle.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.lblFormTitle.Location = New System.Drawing.Point(20, 15)
        Me.lblFormTitle.Name = "lblFormTitle"
        Me.lblFormTitle.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblFormTitle.Size = New System.Drawing.Size(310, 25)
        Me.lblFormTitle.TabIndex = 0
        Me.lblFormTitle.Text = "TIMEPOINT SEQUNCE"
        Me.lblFormTitle.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'tdbgRT
        '
        Me.tdbgRT.AllowUserToAddRows = False
        Me.tdbgRT.AllowUserToDeleteRows = False
        Me.tdbgRT.AllowUserToOrderColumns = True
        DataGridViewCellStyle4.BackColor = System.Drawing.Color.LightYellow
        Me.tdbgRT.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle4
        Me.tdbgRT.AutoGenerateColumns = False
        Me.tdbgRT.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.tdbgRT.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.RouteIDDataGridViewTextBoxColumn, Me.DaysDataGridViewTextBoxColumn, Me.DirectionDataGridViewTextBoxColumn})
        Me.tdbgRT.Cursor = System.Windows.Forms.Cursors.Default
        Me.tdbgRT.DataSource = Me.VwTimePointSequenceBindingSource
        Me.tdbgRT.Location = New System.Drawing.Point(20, 55)
        Me.tdbgRT.MultiSelect = False
        Me.tdbgRT.Name = "tdbgRT"
        Me.tdbgRT.ReadOnly = True
        Me.tdbgRT.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.tdbgRT.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.tdbgRT.Size = New System.Drawing.Size(310, 530)
        Me.tdbgRT.TabIndex = 17
        '
        'RouteIDDataGridViewTextBoxColumn
        '
        Me.RouteIDDataGridViewTextBoxColumn.DataPropertyName = "Route_ID"
        DataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.RouteIDDataGridViewTextBoxColumn.DefaultCellStyle = DataGridViewCellStyle5
        Me.RouteIDDataGridViewTextBoxColumn.HeaderText = "Route ID"
        Me.RouteIDDataGridViewTextBoxColumn.Name = "RouteIDDataGridViewTextBoxColumn"
        Me.RouteIDDataGridViewTextBoxColumn.ReadOnly = True
        '
        'DaysDataGridViewTextBoxColumn
        '
        Me.DaysDataGridViewTextBoxColumn.DataPropertyName = "Days"
        DataGridViewCellStyle6.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.DaysDataGridViewTextBoxColumn.DefaultCellStyle = DataGridViewCellStyle6
        Me.DaysDataGridViewTextBoxColumn.HeaderText = "Days"
        Me.DaysDataGridViewTextBoxColumn.Name = "DaysDataGridViewTextBoxColumn"
        Me.DaysDataGridViewTextBoxColumn.ReadOnly = True
        Me.DaysDataGridViewTextBoxColumn.Width = 75
        '
        'DirectionDataGridViewTextBoxColumn
        '
        Me.DirectionDataGridViewTextBoxColumn.DataPropertyName = "Direction"
        DataGridViewCellStyle7.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.DirectionDataGridViewTextBoxColumn.DefaultCellStyle = DataGridViewCellStyle7
        Me.DirectionDataGridViewTextBoxColumn.HeaderText = "Direction"
        Me.DirectionDataGridViewTextBoxColumn.Name = "DirectionDataGridViewTextBoxColumn"
        Me.DirectionDataGridViewTextBoxColumn.ReadOnly = True
        Me.DirectionDataGridViewTextBoxColumn.Width = 75
        '
        'VwTimePointSequenceBindingSource
        '
        Me.VwTimePointSequenceBindingSource.DataMember = "vwTimePointSequence"
        Me.VwTimePointSequenceBindingSource.DataSource = Me.BusBookDataSet
        '
        'BusBookDataSet
        '
        Me.BusBookDataSet.DataSetName = "BusBookDataSet"
        Me.BusBookDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'VwTimePointSequenceTableAdapter
        '
        Me.VwTimePointSequenceTableAdapter.ClearBeforeFill = True
        '
        'TblTimepointSeqTableAdapter
        '
        Me.TblTimepointSeqTableAdapter.ClearBeforeFill = True
        '
        'Label1
        '
        Me.Label1.AutoSize = True
        Me.Label1.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.Location = New System.Drawing.Point(599, 56)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(36, 14)
        Me.Label1.TabIndex = 19
        Me.Label1.Text = "Days:"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(640, 56)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(76, 14)
        Me.Label2.TabIndex = 20
        Me.Label2.Text = "1 = Weekdays"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(640, 84)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(66, 14)
        Me.Label3.TabIndex = 21
        Me.Label3.Text = "3 - Sundays"
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(640, 70)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(69, 14)
        Me.Label4.TabIndex = 22
        Me.Label4.Text = "2 - Satudays"
        '
        'Label5
        '
        Me.Label5.AutoSize = True
        Me.Label5.Location = New System.Drawing.Point(640, 137)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(51, 14)
        Me.Label5.TabIndex = 26
        Me.Label5.Text = "1 - South"
        '
        'Label6
        '
        Me.Label6.AutoSize = True
        Me.Label6.Location = New System.Drawing.Point(640, 151)
        Me.Label6.Name = "Label6"
        Me.Label6.Size = New System.Drawing.Size(44, 14)
        Me.Label6.TabIndex = 25
        Me.Label6.Text = "2 - East"
        '
        'Label7
        '
        Me.Label7.AutoSize = True
        Me.Label7.Location = New System.Drawing.Point(640, 123)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(49, 14)
        Me.Label7.TabIndex = 24
        Me.Label7.Text = "0 - North"
        '
        'Label8
        '
        Me.Label8.AutoSize = True
        Me.Label8.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label8.Location = New System.Drawing.Point(610, 123)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(25, 14)
        Me.Label8.TabIndex = 23
        Me.Label8.Text = "Dir:"
        '
        'Label9
        '
        Me.Label9.AutoSize = True
        Me.Label9.Location = New System.Drawing.Point(640, 193)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(111, 14)
        Me.Label9.TabIndex = 27
        Me.Label9.Text = "5 - CounterClockwise"
        '
        'Label10
        '
        Me.Label10.AutoSize = True
        Me.Label10.Location = New System.Drawing.Point(640, 179)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(73, 14)
        Me.Label10.TabIndex = 28
        Me.Label10.Text = "4 - Clockwise"
        '
        'Label11
        '
        Me.Label11.AutoSize = True
        Me.Label11.Location = New System.Drawing.Point(640, 165)
        Me.Label11.Name = "Label11"
        Me.Label11.Size = New System.Drawing.Size(48, 14)
        Me.Label11.TabIndex = 29
        Me.Label11.Text = "3 - West"
        '
        'cmdMoveUp
        '
        Me.cmdMoveUp.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdMoveUp.Font = New System.Drawing.Font("Wingdings", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdMoveUp.ForeColor = System.Drawing.Color.Black
        Me.cmdMoveUp.Location = New System.Drawing.Point(595, 236)
        Me.cmdMoveUp.Name = "cmdMoveUp"
        Me.cmdMoveUp.Size = New System.Drawing.Size(26, 43)
        Me.cmdMoveUp.TabIndex = 30
        Me.cmdMoveUp.Text = "G"
        Me.cmdMoveUp.UseVisualStyleBackColor = True
        '
        'cmdMoveDown
        '
        Me.cmdMoveDown.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdMoveDown.Font = New System.Drawing.Font("Wingdings", 24.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdMoveDown.ForeColor = System.Drawing.Color.Black
        Me.cmdMoveDown.Location = New System.Drawing.Point(595, 301)
        Me.cmdMoveDown.Name = "cmdMoveDown"
        Me.cmdMoveDown.Size = New System.Drawing.Size(26, 43)
        Me.cmdMoveDown.TabIndex = 32
        Me.cmdMoveDown.Text = "H"
        Me.cmdMoveDown.UseVisualStyleBackColor = True
        '
        'cmSave
        '
        Me.cmSave.Enabled = False
        Me.cmSave.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.cmSave.Location = New System.Drawing.Point(596, 558)
        Me.cmSave.Name = "cmSave"
        Me.cmSave.Size = New System.Drawing.Size(98, 25)
        Me.cmSave.TabIndex = 33
        Me.cmSave.Text = "Save Changes"
        Me.cmSave.UseVisualStyleBackColor = True
        '
        'frmRouteTP
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(774, 625)
        Me.Controls.Add(DataGridView1)
        Me.Controls.Add(Me.cmSave)
        Me.Controls.Add(Me.cmdMoveDown)
        Me.Controls.Add(Me.cmdMoveUp)
        Me.Controls.Add(Me.Label11)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Label6)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.tdbgRT)
        Me.Controls.Add(Me.lblFormTitle)
        Me.Cursor = System.Windows.Forms.Cursors.Default
        Me.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Location = New System.Drawing.Point(431, 152)
        Me.Name = "frmRouteTP"
        Me.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        CType(DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblTimepointSeqBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TimePointSeq, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.tdbgRT, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.VwTimePointSequenceBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BusBookDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub
#End Region
#Region "Upgrade Support "
    Private Shared m_vb6FormDefInstance As frmRouteTP
    Private Shared m_InitializingDefInstance As Boolean
    Public Shared Property DefInstance() As frmRouteTP
        Get
            If m_vb6FormDefInstance Is Nothing OrElse m_vb6FormDefInstance.IsDisposed Then
                m_InitializingDefInstance = True
                m_vb6FormDefInstance = New frmRouteTP()
                m_InitializingDefInstance = False
            End If
            DefInstance = m_vb6FormDefInstance
        End Get
        Set
            m_vb6FormDefInstance = Value
        End Set
    End Property
#End Region
    Dim cn As ADODB.Connection
    Private Sub frmRouteTP_Load(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load

        Me.TblTimepointSeqTableAdapter.Fill(Me.TimePointSeq.tblTimepointSeq)
        Me.VwTimePointSequenceTableAdapter.Fill(Me.BusBookDataSet.vwTimePointSequence)
        On Error GoTo ErrHandling
        AppTitle = "HASTUS Passing Times Timepoint Sequence Table"
        Me.Text = AppTitle

        Exit Sub
ErrHandling:
        MsgBox("Form internal error. Unable to load form.", MsgBoxStyle.Exclamation, AppTitle)

    End Sub
    Private Sub tdbgRT_SelectionChanged(sender As Object, e As EventArgs) Handles tdbgRT.SelectionChanged

        Dim iRoute As Integer
        Dim iDir As Integer
        Dim iDays As Integer
        Dim vRow As VariantType

        On Error GoTo ErrHandler

        vRow = tdbgRT.CurrentRow.Index
        iRoute = tdbgRT.Item(0, vRow).Value
        iDir = tdbgRT.Item(2, vRow).Value
        iDays = tdbgRT.Item(1, vRow).Value

        If iRoute <= 0 Then Exit Sub

        TblTimepointSeqBindingSource.Filter = "[Route] = " & iRoute & " And [Dir] = " & iDir & " AND [Days] = " & iDays & ""

        Me.cmSave.Enabled = False

        Exit Sub

ErrHandler:
        MsgBox(Err.Source & ": " & Err.Description, MsgBoxStyle.Exclamation, AppTitle)

    End Sub

    Private Sub cmdMoveUp_Click(sender As Object, e As EventArgs) Handles cmdMoveUp.Click
        Dim i As Integer
        On Error GoTo ErrHandler

        Dim sCurrPlaceID As String
        Dim iCurrSeq As Integer
        Dim vCurrRow As VariantType
        Dim iRow As Integer

        On Error GoTo ErrHandler

        vCurrRow = DataGridView1.CurrentRow.Index
        sCurrPlaceID = DataGridView1.Item(0, vCurrRow).Value
        iCurrSeq = DataGridView1.Item(1, vCurrRow).Value

        If DataGridView1.Rows(0).Selected = True Then
            MsgBox("Can't move up.", MsgBoxStyle.Critical, AppTitle)
            Exit Sub
        Else
            iRow = DataGridView1.CurrentRow.Index
            For i = 0 To DataGridView1.Rows.Count - 1
                If DataGridView1.Rows(i).Cells(0).Value = sCurrPlaceID And DataGridView1.Rows(i).Cells(1).Value = iCurrSeq Then
                    DataGridView1.Rows(i).Cells(1).Value = DataGridView1.Rows(i).Cells(1).Value - 1
                ElseIf i = vCurrRow - 1 Then
                    DataGridView1.Rows(i).Cells(1).Value = iCurrSeq
                End If
            Next
        End If

        DataGridView1.Sort(DataGridView1.Columns(1),
        System.ComponentModel.ListSortDirection.Ascending)
        Me.cmSave.Enabled = True

        Exit Sub

ErrHandler:
        MsgBox(Err.Source & ": " & Err.Description)

    End Sub

    Private Sub cmdMoveDown_Click(sender As Object, e As EventArgs) Handles cmdMoveDown.Click
        Dim i As Integer
        On Error GoTo ErrHandler

        Dim sCurrPlaceID As String
        Dim iCurrSeq As Integer
        Dim vCurrRow As VariantType
        Dim iRow As Integer

        On Error GoTo ErrHandler

        vCurrRow = DataGridView1.CurrentRow.Index
        sCurrPlaceID = DataGridView1.Item(0, vCurrRow).Value
        iCurrSeq = DataGridView1.Item(1, vCurrRow).Value

        If DataGridView1.Rows(DataGridView1.Rows.Count - 1).Selected = True Then
            MsgBox("Can't move down. Last row selected", MsgBoxStyle.Critical, AppTitle)
            Exit Sub
        Else
            iRow = DataGridView1.CurrentRow.Index
            For i = 0 To DataGridView1.Rows.Count - 1
                If DataGridView1.Rows(i).Cells(0).Value = sCurrPlaceID And DataGridView1.Rows(i).Cells(1).Value = iCurrSeq Then
                    DataGridView1.Rows(i).Cells(1).Value = DataGridView1.Rows(i).Cells(1).Value + 1
                ElseIf i = vCurrRow + 1 Then
                    DataGridView1.Rows(i).Cells(1).Value = iCurrSeq
                End If
            Next
        End If

        DataGridView1.Sort(DataGridView1.Columns(1),
        System.ComponentModel.ListSortDirection.Ascending)
        Me.cmSave.Enabled = True

        Exit Sub

ErrHandler:
        MsgBox(Err.Source & ": " & Err.Description)

    End Sub

    Private Sub cmSave_Click(sender As Object, e As EventArgs) Handles cmSave.Click
        Dim strSQL As String
        Dim i As Integer
        Dim iRoute As Integer
        Dim iDir As Integer
        Dim iDays As Integer
        Dim vRow As VariantType

        On Error GoTo ErrHandler

        vRow = tdbgRT.CurrentRow.Index
        iRoute = tdbgRT.Item(0, vRow).Value
        iDays = tdbgRT.Item(1, vRow).Value
        iDir = tdbgRT.Item(2, vRow).Value

        strSQL = "DELETE FROM dbo.tblTimepointSeq WHERE Route=" & iRoute
        strSQL = strSQL & " AND Dir=" & iDir & " AND Days=" & iDays
        db.Execute(strSQL)
        strSQL = "DELETE FROM dbo.tblMissingTimepoints WHERE Route=" & iRoute
        strSQL = strSQL & " AND Dir=" & iDir & " AND Days=" & iDays
        db.Execute(strSQL)

        For i = 0 To DataGridView1.Rows.Count - 1
            strSQL = "INSERT INTO dbo.tblTimepointSeq (Route, Dir, Place_ID, Seq, Days) VALUES (" & iRoute & ","
            strSQL = strSQL & iDir & "," & cV2Q_String(DataGridView1.Rows(i).Cells(0).Value) & ","
            strSQL = strSQL & DataGridView1.Rows(i).Cells(1).Value & "," & iDays & ")"
            db.Execute(strSQL)
        Next

        MsgBox("Records have been updated.", MsgBoxStyle.Information, AppTitle)
        Me.cmSave.Enabled = False

        Exit Sub

ErrHandler:
        MsgBox(Err.Source & ": " & Err.Description)

    End Sub

End Class