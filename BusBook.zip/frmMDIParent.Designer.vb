﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmMDIParent
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub


    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmMDIParent))
        Me.ToolTip = New System.Windows.Forms.ToolTip(Me.components)
        Me.SplitContainer1 = New System.Windows.Forms.SplitContainer()
        Me.SplitContainer2 = New System.Windows.Forms.SplitContainer()
        Me.cmdExit = New System.Windows.Forms.Button()
        Me.cmdHome = New System.Windows.Forms.Button()
        Me.cmdLandmarkAlias = New System.Windows.Forms.Button()
        Me.cmdViewTP = New System.Windows.Forms.Button()
        Me.cmdLayoverZones = New System.Windows.Forms.Button()
        Me.cmdBusRouteDescriptions = New System.Windows.Forms.Button()
        Me.cmdImport = New System.Windows.Forms.Button()
        Me.cmdLayover = New System.Windows.Forms.Button()
        Me.cmdBook = New System.Windows.Forms.Button()
        CType(Me.SplitContainer1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainer1.Panel2.SuspendLayout()
        Me.SplitContainer1.SuspendLayout()
        CType(Me.SplitContainer2, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SplitContainer2.Panel1.SuspendLayout()
        Me.SplitContainer2.SuspendLayout()
        Me.SuspendLayout()
        '
        'SplitContainer1
        '
        Me.SplitContainer1.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer1.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer1.Name = "SplitContainer1"
        Me.SplitContainer1.Orientation = System.Windows.Forms.Orientation.Horizontal
        '
        'SplitContainer1.Panel1
        '
        Me.SplitContainer1.Panel1.BackgroundImage = Global.BusBook.My.Resources.Resources.Banner
        Me.SplitContainer1.Panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        '
        'SplitContainer1.Panel2
        '
        Me.SplitContainer1.Panel2.Controls.Add(Me.SplitContainer2)
        Me.SplitContainer1.Size = New System.Drawing.Size(1134, 755)
        Me.SplitContainer1.SplitterDistance = 92
        Me.SplitContainer1.TabIndex = 9
        '
        'SplitContainer2
        '
        Me.SplitContainer2.Dock = System.Windows.Forms.DockStyle.Fill
        Me.SplitContainer2.FixedPanel = System.Windows.Forms.FixedPanel.Panel1
        Me.SplitContainer2.IsSplitterFixed = True
        Me.SplitContainer2.Location = New System.Drawing.Point(0, 0)
        Me.SplitContainer2.Name = "SplitContainer2"
        '
        'SplitContainer2.Panel1
        '
        Me.SplitContainer2.Panel1.AutoScroll = True
        Me.SplitContainer2.Panel1.AutoScrollMinSize = New System.Drawing.Size(200, 590)
        Me.SplitContainer2.Panel1.BackColor = System.Drawing.Color.Transparent
        Me.SplitContainer2.Panel1.BackgroundImage = Global.BusBook.My.Resources.Resources.Background
        Me.SplitContainer2.Panel1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.SplitContainer2.Panel1.Controls.Add(Me.cmdExit)
        Me.SplitContainer2.Panel1.Controls.Add(Me.cmdHome)
        Me.SplitContainer2.Panel1.Controls.Add(Me.cmdLandmarkAlias)
        Me.SplitContainer2.Panel1.Controls.Add(Me.cmdViewTP)
        Me.SplitContainer2.Panel1.Controls.Add(Me.cmdLayoverZones)
        Me.SplitContainer2.Panel1.Controls.Add(Me.cmdBusRouteDescriptions)
        Me.SplitContainer2.Panel1.Controls.Add(Me.cmdImport)
        Me.SplitContainer2.Panel1.Controls.Add(Me.cmdLayover)
        Me.SplitContainer2.Panel1.Controls.Add(Me.cmdBook)
        '
        'SplitContainer2.Panel2
        '
        Me.SplitContainer2.Panel2.AutoScroll = True
        Me.SplitContainer2.Panel2.AutoScrollMinSize = New System.Drawing.Size(800, 590)
        Me.SplitContainer2.Panel2.BackColor = System.Drawing.Color.White
        Me.SplitContainer2.Panel2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch
        Me.SplitContainer2.Size = New System.Drawing.Size(1134, 659)
        Me.SplitContainer2.SplitterDistance = 228
        Me.SplitContainer2.TabIndex = 0
        '
        'cmdExit
        '
        Me.cmdExit.BackColor = System.Drawing.Color.Transparent
        Me.cmdExit.Cursor = System.Windows.Forms.Cursors.Hand
        Me.cmdExit.FlatAppearance.BorderSize = 0
        Me.cmdExit.FlatAppearance.MouseOverBackColor = System.Drawing.Color.SteelBlue
        Me.cmdExit.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdExit.Font = New System.Drawing.Font("Calibri Light", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdExit.ForeColor = System.Drawing.Color.White
        Me.cmdExit.Image = Global.BusBook.My.Resources.Resources._Exit
        Me.cmdExit.Location = New System.Drawing.Point(6, 577)
        Me.cmdExit.Name = "cmdExit"
        Me.cmdExit.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdExit.Size = New System.Drawing.Size(215, 66)
        Me.cmdExit.TabIndex = 25
        Me.cmdExit.UseVisualStyleBackColor = False
        '
        'cmdHome
        '
        Me.cmdHome.BackColor = System.Drawing.Color.Transparent
        Me.cmdHome.Cursor = System.Windows.Forms.Cursors.Hand
        Me.cmdHome.FlatAppearance.BorderSize = 0
        Me.cmdHome.FlatAppearance.MouseDownBackColor = System.Drawing.Color.DarkGray
        Me.cmdHome.FlatAppearance.MouseOverBackColor = System.Drawing.Color.SteelBlue
        Me.cmdHome.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdHome.Font = New System.Drawing.Font("Calibri Light", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdHome.ForeColor = System.Drawing.Color.White
        Me.cmdHome.Image = Global.BusBook.My.Resources.Resources.Home
        Me.cmdHome.Location = New System.Drawing.Point(6, 17)
        Me.cmdHome.Name = "cmdHome"
        Me.cmdHome.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdHome.Size = New System.Drawing.Size(215, 66)
        Me.cmdHome.TabIndex = 24
        Me.cmdHome.UseVisualStyleBackColor = False
        '
        'cmdLandmarkAlias
        '
        Me.cmdLandmarkAlias.BackColor = System.Drawing.Color.Transparent
        Me.cmdLandmarkAlias.Cursor = System.Windows.Forms.Cursors.Hand
        Me.cmdLandmarkAlias.FlatAppearance.BorderSize = 0
        Me.cmdLandmarkAlias.FlatAppearance.MouseOverBackColor = System.Drawing.Color.SteelBlue
        Me.cmdLandmarkAlias.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdLandmarkAlias.Font = New System.Drawing.Font("Calibri Light", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdLandmarkAlias.ForeColor = System.Drawing.Color.White
        Me.cmdLandmarkAlias.Image = Global.BusBook.My.Resources.Resources.LandmarkAlias
        Me.cmdLandmarkAlias.Location = New System.Drawing.Point(6, 367)
        Me.cmdLandmarkAlias.Name = "cmdLandmarkAlias"
        Me.cmdLandmarkAlias.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdLandmarkAlias.Size = New System.Drawing.Size(215, 66)
        Me.cmdLandmarkAlias.TabIndex = 23
        Me.cmdLandmarkAlias.UseVisualStyleBackColor = False
        '
        'cmdViewTP
        '
        Me.cmdViewTP.BackColor = System.Drawing.Color.Transparent
        Me.cmdViewTP.Cursor = System.Windows.Forms.Cursors.Hand
        Me.cmdViewTP.FlatAppearance.BorderSize = 0
        Me.cmdViewTP.FlatAppearance.MouseOverBackColor = System.Drawing.Color.SteelBlue
        Me.cmdViewTP.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdViewTP.Font = New System.Drawing.Font("Calibri Light", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdViewTP.ForeColor = System.Drawing.Color.White
        Me.cmdViewTP.Image = Global.BusBook.My.Resources.Resources.ViewTimepointSeq
        Me.cmdViewTP.Location = New System.Drawing.Point(6, 227)
        Me.cmdViewTP.Name = "cmdViewTP"
        Me.cmdViewTP.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdViewTP.Size = New System.Drawing.Size(215, 66)
        Me.cmdViewTP.TabIndex = 6
        Me.cmdViewTP.UseVisualStyleBackColor = False
        '
        'cmdLayoverZones
        '
        Me.cmdLayoverZones.BackColor = System.Drawing.Color.Transparent
        Me.cmdLayoverZones.Cursor = System.Windows.Forms.Cursors.Hand
        Me.cmdLayoverZones.FlatAppearance.BorderSize = 0
        Me.cmdLayoverZones.FlatAppearance.MouseOverBackColor = System.Drawing.Color.SteelBlue
        Me.cmdLayoverZones.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdLayoverZones.Font = New System.Drawing.Font("Calibri Light", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdLayoverZones.ForeColor = System.Drawing.Color.White
        Me.cmdLayoverZones.Image = Global.BusBook.My.Resources.Resources.ViewLayoverZone
        Me.cmdLayoverZones.Location = New System.Drawing.Point(6, 507)
        Me.cmdLayoverZones.Name = "cmdLayoverZones"
        Me.cmdLayoverZones.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdLayoverZones.Size = New System.Drawing.Size(215, 66)
        Me.cmdLayoverZones.TabIndex = 21
        Me.cmdLayoverZones.UseVisualStyleBackColor = False
        '
        'cmdBusRouteDescriptions
        '
        Me.cmdBusRouteDescriptions.BackColor = System.Drawing.Color.Transparent
        Me.cmdBusRouteDescriptions.Cursor = System.Windows.Forms.Cursors.Hand
        Me.cmdBusRouteDescriptions.FlatAppearance.BorderSize = 0
        Me.cmdBusRouteDescriptions.FlatAppearance.MouseOverBackColor = System.Drawing.Color.SteelBlue
        Me.cmdBusRouteDescriptions.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdBusRouteDescriptions.Font = New System.Drawing.Font("Calibri Light", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdBusRouteDescriptions.ForeColor = System.Drawing.Color.White
        Me.cmdBusRouteDescriptions.Image = Global.BusBook.My.Resources.Resources.BusRouteDesc
        Me.cmdBusRouteDescriptions.Location = New System.Drawing.Point(6, 437)
        Me.cmdBusRouteDescriptions.Name = "cmdBusRouteDescriptions"
        Me.cmdBusRouteDescriptions.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdBusRouteDescriptions.Size = New System.Drawing.Size(215, 66)
        Me.cmdBusRouteDescriptions.TabIndex = 22
        Me.cmdBusRouteDescriptions.UseVisualStyleBackColor = False
        '
        'cmdImport
        '
        Me.cmdImport.BackColor = System.Drawing.Color.Transparent
        Me.cmdImport.Cursor = System.Windows.Forms.Cursors.Hand
        Me.cmdImport.FlatAppearance.BorderSize = 0
        Me.cmdImport.FlatAppearance.MouseOverBackColor = System.Drawing.Color.SteelBlue
        Me.cmdImport.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdImport.Font = New System.Drawing.Font("Calibri Light", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdImport.ForeColor = System.Drawing.Color.White
        Me.cmdImport.Image = Global.BusBook.My.Resources.Resources.ImportPassingTimes2
        Me.cmdImport.Location = New System.Drawing.Point(6, 87)
        Me.cmdImport.Name = "cmdImport"
        Me.cmdImport.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdImport.Size = New System.Drawing.Size(215, 66)
        Me.cmdImport.TabIndex = 4
        Me.cmdImport.UseVisualStyleBackColor = False
        '
        'cmdLayover
        '
        Me.cmdLayover.BackColor = System.Drawing.Color.Transparent
        Me.cmdLayover.Cursor = System.Windows.Forms.Cursors.Hand
        Me.cmdLayover.FlatAppearance.BorderSize = 0
        Me.cmdLayover.FlatAppearance.MouseOverBackColor = System.Drawing.Color.SteelBlue
        Me.cmdLayover.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdLayover.Font = New System.Drawing.Font("Calibri Light", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdLayover.ForeColor = System.Drawing.Color.White
        Me.cmdLayover.Image = Global.BusBook.My.Resources.Resources.ManageLayoverZone
        Me.cmdLayover.Location = New System.Drawing.Point(6, 157)
        Me.cmdLayover.Name = "cmdLayover"
        Me.cmdLayover.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdLayover.Size = New System.Drawing.Size(215, 66)
        Me.cmdLayover.TabIndex = 5
        Me.cmdLayover.UseVisualStyleBackColor = False
        '
        'cmdBook
        '
        Me.cmdBook.BackColor = System.Drawing.Color.Transparent
        Me.cmdBook.Cursor = System.Windows.Forms.Cursors.Hand
        Me.cmdBook.FlatAppearance.BorderSize = 0
        Me.cmdBook.FlatAppearance.MouseOverBackColor = System.Drawing.Color.SteelBlue
        Me.cmdBook.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.cmdBook.Font = New System.Drawing.Font("Calibri Light", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdBook.ForeColor = System.Drawing.Color.White
        Me.cmdBook.Image = Global.BusBook.My.Resources.Resources.CreateTimeTable
        Me.cmdBook.Location = New System.Drawing.Point(6, 297)
        Me.cmdBook.Name = "cmdBook"
        Me.cmdBook.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdBook.Size = New System.Drawing.Size(215, 66)
        Me.cmdBook.TabIndex = 7
        Me.cmdBook.UseVisualStyleBackColor = False
        '
        'frmMDIParent
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.ClientSize = New System.Drawing.Size(1134, 755)
        Me.Controls.Add(Me.SplitContainer1)
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.IsMdiContainer = True
        Me.Name = "frmMDIParent"
        Me.Text = "OCTA Bus Book"
        Me.SplitContainer1.Panel2.ResumeLayout(False)
        CType(Me.SplitContainer1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer1.ResumeLayout(False)
        Me.SplitContainer2.Panel1.ResumeLayout(False)
        CType(Me.SplitContainer2, System.ComponentModel.ISupportInitialize).EndInit()
        Me.SplitContainer2.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
    Friend WithEvents ToolTip As System.Windows.Forms.ToolTip
    Friend WithEvents SplitContainer1 As SplitContainer
    Friend WithEvents SplitContainer2 As SplitContainer
    Public WithEvents cmdViewTP As Button
    Public WithEvents cmdImport As Button
    Public WithEvents cmdLayover As Button
    Public WithEvents cmdBook As Button
    Public WithEvents cmdLandmarkAlias As Button
    Public WithEvents cmdLayoverZones As Button
    Public WithEvents cmdBusRouteDescriptions As Button
    Public WithEvents cmdHome As Button
    Public WithEvents cmdExit As Button
End Class
