Option Strict Off
Option Explicit On
Friend Class clsTimePoint
	
	Private m_PlaceID As String
	Private m_Time As Short
	
	
	Public Property PlaceID() As String
		Get
			PlaceID = m_PlaceID
		End Get
		Set(ByVal Value As String)
			m_PlaceID = Value
		End Set
	End Property
	
	
	Public Property time() As Short
		Get
			time = m_Time
		End Get
		Set(ByVal Value As Short)
			m_Time = Value
		End Set
	End Property
End Class