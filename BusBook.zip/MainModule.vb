Option Strict Off
Option Explicit On

Module MainModule
    Public AppTitle As String
    Public AppName As String
    Public DB_PASSWORD As String
    Public DB_SERVER As String
    Public DB_USER As String
    Public DB_NAME As String
    Public db As New ADODB.Connection
    Public oConn As ADODB.Connection
    Public sConn As String
    Public DestPath As String

    Sub CreateConnection()

        DB_PASSWORD = "Oct@!2345"
        DB_SERVER = "ormsql24"
        DB_USER = "InHouseApp_User"
        DB_NAME = "BusBook"

        'Use SQL Server 13 driver
        db.ConnectionString = "Driver={ODBC Driver 13 for SQL Server};server=" & DB_SERVER & ";database=" & DB_NAME & ";uid=" & DB_USER & ";pwd=" & DB_PASSWORD & ";"
        db.Open()

        sConn = "Data Source=" & DB_SERVER & ";Initial Catalog=" & DB_NAME & ";UID=" & DB_USER & ";PWD=" & DB_PASSWORD & ""

    End Sub


End Module