Module UpgradeSupport
	Friend ExcelGlobal_definst As New Microsoft.Office.Interop.Excel.[Global]
End Module