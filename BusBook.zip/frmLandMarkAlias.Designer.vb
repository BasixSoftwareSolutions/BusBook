﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmLandMarkAlias
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.dgvLandmarkAlias = New System.Windows.Forms.DataGridView()
        Me.PLACEIDDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ALIASDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TblLandmarksAliasBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.LandMarksAlias = New BusBook.LandMarksAlias()
        Me.lblFormTitle = New System.Windows.Forms.Label()
        Me.TblLandmarksAliasTableAdapter = New BusBook.LandMarksAliasTableAdapters.tblLandmarksAliasTableAdapter()
        Me.cmdDelete = New System.Windows.Forms.Button()
        Me.cmdSave = New System.Windows.Forms.Button()
        Me.cmdAddNew = New System.Windows.Forms.Button()
        CType(Me.dgvLandmarkAlias, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblLandmarksAliasBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.LandMarksAlias, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'dgvLandmarkAlias
        '
        DataGridViewCellStyle2.BackColor = System.Drawing.Color.LightYellow
        Me.dgvLandmarkAlias.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle2
        Me.dgvLandmarkAlias.AutoGenerateColumns = False
        Me.dgvLandmarkAlias.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvLandmarkAlias.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.PLACEIDDataGridViewTextBoxColumn, Me.ALIASDataGridViewTextBoxColumn})
        Me.dgvLandmarkAlias.DataSource = Me.TblLandmarksAliasBindingSource
        Me.dgvLandmarkAlias.Location = New System.Drawing.Point(20, 55)
        Me.dgvLandmarkAlias.Name = "dgvLandmarkAlias"
        Me.dgvLandmarkAlias.Size = New System.Drawing.Size(388, 530)
        Me.dgvLandmarkAlias.TabIndex = 0
        '
        'PLACEIDDataGridViewTextBoxColumn
        '
        Me.PLACEIDDataGridViewTextBoxColumn.DataPropertyName = "PLACE_ID"
        Me.PLACEIDDataGridViewTextBoxColumn.HeaderText = "PLACE ID"
        Me.PLACEIDDataGridViewTextBoxColumn.Name = "PLACEIDDataGridViewTextBoxColumn"
        Me.PLACEIDDataGridViewTextBoxColumn.Width = 125
        '
        'ALIASDataGridViewTextBoxColumn
        '
        Me.ALIASDataGridViewTextBoxColumn.DataPropertyName = "ALIAS"
        Me.ALIASDataGridViewTextBoxColumn.HeaderText = "ALIAS"
        Me.ALIASDataGridViewTextBoxColumn.Name = "ALIASDataGridViewTextBoxColumn"
        Me.ALIASDataGridViewTextBoxColumn.Width = 200
        '
        'TblLandmarksAliasBindingSource
        '
        Me.TblLandmarksAliasBindingSource.DataMember = "tblLandmarksAlias"
        Me.TblLandmarksAliasBindingSource.DataSource = Me.LandMarksAlias
        '
        'LandMarksAlias
        '
        Me.LandMarksAlias.DataSetName = "LandMarksAlias"
        Me.LandMarksAlias.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'lblFormTitle
        '
        Me.lblFormTitle.BackColor = System.Drawing.Color.Transparent
        Me.lblFormTitle.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblFormTitle.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.lblFormTitle.Font = New System.Drawing.Font("Verdana", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFormTitle.ForeColor = System.Drawing.Color.Gray
        Me.lblFormTitle.Location = New System.Drawing.Point(20, 15)
        Me.lblFormTitle.Name = "lblFormTitle"
        Me.lblFormTitle.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblFormTitle.Size = New System.Drawing.Size(313, 25)
        Me.lblFormTitle.TabIndex = 3
        Me.lblFormTitle.Text = "LANDMARK ALIAS"
        Me.lblFormTitle.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'TblLandmarksAliasTableAdapter
        '
        Me.TblLandmarksAliasTableAdapter.ClearBeforeFill = True
        '
        'cmdDelete
        '
        Me.cmdDelete.Image = Global.BusBook.My.Resources.Resources.DeleteEvent_16x
        Me.cmdDelete.Location = New System.Drawing.Point(108, 591)
        Me.cmdDelete.Name = "cmdDelete"
        Me.cmdDelete.Size = New System.Drawing.Size(75, 24)
        Me.cmdDelete.TabIndex = 39
        Me.cmdDelete.Text = "Delete"
        Me.cmdDelete.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.cmdDelete.UseVisualStyleBackColor = True
        '
        'cmdSave
        '
        Me.cmdSave.Image = Global.BusBook.My.Resources.Resources.Save_16x_32
        Me.cmdSave.Location = New System.Drawing.Point(189, 591)
        Me.cmdSave.Name = "cmdSave"
        Me.cmdSave.Size = New System.Drawing.Size(97, 24)
        Me.cmdSave.TabIndex = 38
        Me.cmdSave.Text = "Save Record"
        Me.cmdSave.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.cmdSave.UseVisualStyleBackColor = True
        '
        'cmdAddNew
        '
        Me.cmdAddNew.Image = Global.BusBook.My.Resources.Resources.Add_thin_10x_16x
        Me.cmdAddNew.Location = New System.Drawing.Point(19, 591)
        Me.cmdAddNew.Name = "cmdAddNew"
        Me.cmdAddNew.Size = New System.Drawing.Size(83, 24)
        Me.cmdAddNew.TabIndex = 37
        Me.cmdAddNew.Text = "Add New"
        Me.cmdAddNew.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.cmdAddNew.UseVisualStyleBackColor = True
        '
        'frmLandMarkAlias
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(445, 625)
        Me.ControlBox = False
        Me.Controls.Add(Me.cmdDelete)
        Me.Controls.Add(Me.cmdSave)
        Me.Controls.Add(Me.cmdAddNew)
        Me.Controls.Add(Me.lblFormTitle)
        Me.Controls.Add(Me.dgvLandmarkAlias)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmLandMarkAlias"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Land Mark Alias"
        CType(Me.dgvLandmarkAlias, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblLandmarksAliasBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.LandMarksAlias, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents dgvLandmarkAlias As DataGridView
    Friend WithEvents LandMarksAlias As LandMarksAlias
    Friend WithEvents TblLandmarksAliasBindingSource As BindingSource
    Friend WithEvents TblLandmarksAliasTableAdapter As LandMarksAliasTableAdapters.tblLandmarksAliasTableAdapter
    Friend WithEvents PLACEIDDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents ALIASDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Public WithEvents lblFormTitle As Label
    Friend WithEvents cmdDelete As Button
    Friend WithEvents cmdSave As Button
    Friend WithEvents cmdAddNew As Button
End Class
