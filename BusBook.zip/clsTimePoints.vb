Option Strict Off
Option Explicit On
Friend Class clsTimePoints
	Implements System.Collections.IEnumerable
	'clsTimePoints is a wrapper of collection class.
	'It works like collection, except it only contains one type of objects.
	'Its Add method automatically creates a TimePoint object.
	
	Private m_TimePoints As Collection
	
	Public ReadOnly Property Count() As Integer
		Get
			Count = m_TimePoints.Count()
		End Get
	End Property
	
	Public ReadOnly Property Item(ByVal index As Integer) As clsTimePoint
		Get
			Item = m_TimePoints.Item(index)
		End Get
	End Property

    'enable for...each
    'in the procedure attributes of tool, set Procedure ID as -4 and hide this member
    'Public ReadOnly Property NewEnum() As stdole.IUnknown
    'Get
    'NewEnum = m_TimePoints._NewEnum
    'End Get
    'End Property

    Public Function GetEnumerator() As System.Collections.IEnumerator Implements System.Collections.IEnumerable.GetEnumerator
        GetEnumerator = m_TimePoints.GetEnumerator
    End Function
	
	Public Sub Add(ByRef pid As String, ByRef time As Short)
		Dim tp As New clsTimePoint
		tp.PlaceID = pid
		tp.time = time
		m_TimePoints.Add(tp)
	End Sub
	
	Public Sub Remove(ByRef index As Integer)
		m_TimePoints.Remove(index)
	End Sub

    Private Sub Class_Initialize_Renamed()
        m_TimePoints = New Collection
    End Sub
    Public Sub New()
		MyBase.New()
		Class_Initialize_Renamed()
	End Sub

    Private Sub Class_Terminate_Renamed()
        m_TimePoints = Nothing
    End Sub
    Protected Overrides Sub Finalize()
		Class_Terminate_Renamed()
		MyBase.Finalize()
	End Sub
End Class