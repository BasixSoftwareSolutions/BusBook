﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()>
Partial Class frmLayoverZones
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()>
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()>
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.dgvLayoverZone = New System.Windows.Forms.DataGridView()
        Me.IDDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.PlaceIDDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.RouteDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.RemoteDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.CreatedDateDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TblLayzTimePointBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.BusStopManagementDataSet = New BusBook.BusStopManagementDataSet()
        Me.TblLayzTimePointTableAdapter = New BusBook.BusStopManagementDataSetTableAdapters.tblLayzTimePointTableAdapter()
        Me.lblFormTitle = New System.Windows.Forms.Label()
        Me.cmdDelete = New System.Windows.Forms.Button()
        Me.cmdSave = New System.Windows.Forms.Button()
        Me.cmdAddNew = New System.Windows.Forms.Button()
        CType(Me.dgvLayoverZone, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblLayzTimePointBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BusStopManagementDataSet, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'dgvLayoverZone
        '
        DataGridViewCellStyle2.BackColor = System.Drawing.Color.LightYellow
        Me.dgvLayoverZone.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle2
        Me.dgvLayoverZone.AutoGenerateColumns = False
        Me.dgvLayoverZone.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvLayoverZone.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.IDDataGridViewTextBoxColumn, Me.PlaceIDDataGridViewTextBoxColumn, Me.RouteDataGridViewTextBoxColumn, Me.RemoteDataGridViewTextBoxColumn, Me.CreatedDateDataGridViewTextBoxColumn})
        Me.dgvLayoverZone.DataSource = Me.TblLayzTimePointBindingSource
        Me.dgvLayoverZone.Location = New System.Drawing.Point(20, 55)
        Me.dgvLayoverZone.Name = "dgvLayoverZone"
        Me.dgvLayoverZone.Size = New System.Drawing.Size(360, 530)
        Me.dgvLayoverZone.TabIndex = 0
        '
        'IDDataGridViewTextBoxColumn
        '
        Me.IDDataGridViewTextBoxColumn.DataPropertyName = "ID"
        Me.IDDataGridViewTextBoxColumn.HeaderText = "ID"
        Me.IDDataGridViewTextBoxColumn.Name = "IDDataGridViewTextBoxColumn"
        Me.IDDataGridViewTextBoxColumn.ReadOnly = True
        Me.IDDataGridViewTextBoxColumn.Visible = False
        Me.IDDataGridViewTextBoxColumn.Width = 5
        '
        'PlaceIDDataGridViewTextBoxColumn
        '
        Me.PlaceIDDataGridViewTextBoxColumn.DataPropertyName = "Place_ID"
        Me.PlaceIDDataGridViewTextBoxColumn.HeaderText = "Place"
        Me.PlaceIDDataGridViewTextBoxColumn.Name = "PlaceIDDataGridViewTextBoxColumn"
        '
        'RouteDataGridViewTextBoxColumn
        '
        Me.RouteDataGridViewTextBoxColumn.DataPropertyName = "Route"
        Me.RouteDataGridViewTextBoxColumn.HeaderText = "Route"
        Me.RouteDataGridViewTextBoxColumn.Name = "RouteDataGridViewTextBoxColumn"
        '
        'RemoteDataGridViewTextBoxColumn
        '
        Me.RemoteDataGridViewTextBoxColumn.DataPropertyName = "Remote"
        Me.RemoteDataGridViewTextBoxColumn.HeaderText = "Remote"
        Me.RemoteDataGridViewTextBoxColumn.Name = "RemoteDataGridViewTextBoxColumn"
        '
        'CreatedDateDataGridViewTextBoxColumn
        '
        Me.CreatedDateDataGridViewTextBoxColumn.DataPropertyName = "CreatedDate"
        Me.CreatedDateDataGridViewTextBoxColumn.HeaderText = "CreatedDate"
        Me.CreatedDateDataGridViewTextBoxColumn.Name = "CreatedDateDataGridViewTextBoxColumn"
        Me.CreatedDateDataGridViewTextBoxColumn.Visible = False
        Me.CreatedDateDataGridViewTextBoxColumn.Width = 5
        '
        'TblLayzTimePointBindingSource
        '
        Me.TblLayzTimePointBindingSource.DataMember = "tblLayzTimePoint"
        Me.TblLayzTimePointBindingSource.DataSource = Me.BusStopManagementDataSet
        '
        'BusStopManagementDataSet
        '
        Me.BusStopManagementDataSet.DataSetName = "BusStopManagementDataSet"
        Me.BusStopManagementDataSet.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'TblLayzTimePointTableAdapter
        '
        Me.TblLayzTimePointTableAdapter.ClearBeforeFill = True
        '
        'lblFormTitle
        '
        Me.lblFormTitle.BackColor = System.Drawing.Color.Transparent
        Me.lblFormTitle.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblFormTitle.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.lblFormTitle.Font = New System.Drawing.Font("Verdana", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFormTitle.ForeColor = System.Drawing.Color.Gray
        Me.lblFormTitle.Location = New System.Drawing.Point(20, 15)
        Me.lblFormTitle.Name = "lblFormTitle"
        Me.lblFormTitle.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblFormTitle.Size = New System.Drawing.Size(304, 25)
        Me.lblFormTitle.TabIndex = 1
        Me.lblFormTitle.Text = "EDIT/VIEW LAYOVER ZONES"
        Me.lblFormTitle.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'cmdDelete
        '
        Me.cmdDelete.Image = Global.BusBook.My.Resources.Resources.DeleteEvent_16x
        Me.cmdDelete.Location = New System.Drawing.Point(110, 593)
        Me.cmdDelete.Name = "cmdDelete"
        Me.cmdDelete.Size = New System.Drawing.Size(75, 24)
        Me.cmdDelete.TabIndex = 39
        Me.cmdDelete.Text = "Delete"
        Me.cmdDelete.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.cmdDelete.UseVisualStyleBackColor = True
        '
        'cmdSave
        '
        Me.cmdSave.Image = Global.BusBook.My.Resources.Resources.Save_16x_32
        Me.cmdSave.Location = New System.Drawing.Point(191, 593)
        Me.cmdSave.Name = "cmdSave"
        Me.cmdSave.Size = New System.Drawing.Size(97, 24)
        Me.cmdSave.TabIndex = 38
        Me.cmdSave.Text = "Save Record"
        Me.cmdSave.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.cmdSave.UseVisualStyleBackColor = True
        '
        'cmdAddNew
        '
        Me.cmdAddNew.Image = Global.BusBook.My.Resources.Resources.Add_thin_10x_16x
        Me.cmdAddNew.Location = New System.Drawing.Point(21, 593)
        Me.cmdAddNew.Name = "cmdAddNew"
        Me.cmdAddNew.Size = New System.Drawing.Size(83, 24)
        Me.cmdAddNew.TabIndex = 37
        Me.cmdAddNew.Text = "Add New"
        Me.cmdAddNew.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.cmdAddNew.UseVisualStyleBackColor = True
        '
        'frmLayoverZones
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(417, 625)
        Me.ControlBox = False
        Me.Controls.Add(Me.cmdDelete)
        Me.Controls.Add(Me.cmdSave)
        Me.Controls.Add(Me.cmdAddNew)
        Me.Controls.Add(Me.lblFormTitle)
        Me.Controls.Add(Me.dgvLayoverZone)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "frmLayoverZones"
        Me.SizeGripStyle = System.Windows.Forms.SizeGripStyle.Hide
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "Layover Zones"
        CType(Me.dgvLayoverZone, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblLayzTimePointBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BusStopManagementDataSet, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub

    Friend WithEvents dgvLayoverZone As DataGridView
    Friend WithEvents BusStopManagementDataSet As BusStopManagementDataSet
    Friend WithEvents TblLayzTimePointBindingSource As BindingSource
    Friend WithEvents TblLayzTimePointTableAdapter As BusStopManagementDataSetTableAdapters.tblLayzTimePointTableAdapter
    Friend WithEvents IDDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents PlaceIDDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents RouteDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents RemoteDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents CreatedDateDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Public WithEvents lblFormTitle As Label
    Friend WithEvents cmdDelete As Button
    Friend WithEvents cmdSave As Button
    Friend WithEvents cmdAddNew As Button
End Class
