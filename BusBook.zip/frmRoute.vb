Option Strict Off
Option Explicit On
Imports VB = Microsoft.VisualBasic
Imports Microsoft.Office.Interop
'Imports Microsoft.Office.Interop.Excel
Friend Class frmRoute
	Inherits System.Windows.Forms.Form
#Region "Windows Form Designer generated code "
	Public Sub New()
		MyBase.New()
		If m_vb6FormDefInstance Is Nothing Then
			If m_InitializingDefInstance Then
				m_vb6FormDefInstance = Me
			Else
				Try 
					'For the start-up form, the first instance created is the default instance.
					If System.Reflection.Assembly.GetExecutingAssembly.EntryPoint.DeclaringType Is Me.GetType Then
						m_vb6FormDefInstance = Me
					End If
				Catch
				End Try
			End If
		End If
		'This call is required by the Windows Form Designer.
		InitializeComponent()
	End Sub
	'Form overrides dispose to clean up the component list.
	Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
		If Disposing Then
			If Not components Is Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(Disposing)
	End Sub
	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer
	Public ToolTip1 As System.Windows.Forms.ToolTip
    Public WithEvents cmdSelectAll As System.Windows.Forms.Button
    Public WithEvents cmdClearAll As System.Windows.Forms.Button
    Public WithEvents cmdBook As System.Windows.Forms.Button
    Friend WithEvents DataGridView1 As DataGridView
    Friend WithEvents Panel1 As Panel
    Friend WithEvents Selected As DataGridViewCheckBoxColumn
    Friend WithEvents Route As DataGridViewTextBoxColumn
    Public WithEvents cmdSelectFolder As Button
    Friend WithEvents ProgressBar1 As ProgressBar
    Friend WithEvents lblProcess As Label
    Friend WithEvents FolderBrowserDialog1 As FolderBrowserDialog
    Friend WithEvents lblFolderDir As Label
    Public WithEvents lblFormTitle As System.Windows.Forms.Label
    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmRoute))
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.cmdSelectAll = New System.Windows.Forms.Button()
        Me.cmdClearAll = New System.Windows.Forms.Button()
        Me.cmdBook = New System.Windows.Forms.Button()
        Me.lblFormTitle = New System.Windows.Forms.Label()
        Me.DataGridView1 = New System.Windows.Forms.DataGridView()
        Me.Selected = New System.Windows.Forms.DataGridViewCheckBoxColumn()
        Me.Route = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.Panel1 = New System.Windows.Forms.Panel()
        Me.cmdSelectFolder = New System.Windows.Forms.Button()
        Me.ProgressBar1 = New System.Windows.Forms.ProgressBar()
        Me.lblProcess = New System.Windows.Forms.Label()
        Me.FolderBrowserDialog1 = New System.Windows.Forms.FolderBrowserDialog()
        Me.lblFolderDir = New System.Windows.Forms.Label()
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.Panel1.SuspendLayout()
        Me.SuspendLayout()
        '
        'cmdSelectAll
        '
        Me.cmdSelectAll.BackColor = System.Drawing.SystemColors.Control
        Me.cmdSelectAll.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdSelectAll.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdSelectAll.ForeColor = System.Drawing.Color.Black
        Me.cmdSelectAll.Location = New System.Drawing.Point(8, 12)
        Me.cmdSelectAll.Name = "cmdSelectAll"
        Me.cmdSelectAll.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdSelectAll.Size = New System.Drawing.Size(129, 33)
        Me.cmdSelectAll.TabIndex = 2
        Me.cmdSelectAll.Text = "&Select All"
        Me.cmdSelectAll.UseVisualStyleBackColor = False
        '
        'cmdClearAll
        '
        Me.cmdClearAll.BackColor = System.Drawing.SystemColors.Control
        Me.cmdClearAll.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdClearAll.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdClearAll.ForeColor = System.Drawing.Color.Black
        Me.cmdClearAll.Location = New System.Drawing.Point(8, 60)
        Me.cmdClearAll.Name = "cmdClearAll"
        Me.cmdClearAll.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdClearAll.Size = New System.Drawing.Size(129, 33)
        Me.cmdClearAll.TabIndex = 3
        Me.cmdClearAll.Text = "&Clear All"
        Me.cmdClearAll.UseVisualStyleBackColor = False
        '
        'cmdBook
        '
        Me.cmdBook.BackColor = System.Drawing.SystemColors.Control
        Me.cmdBook.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdBook.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdBook.ForeColor = System.Drawing.Color.Black
        Me.cmdBook.Location = New System.Drawing.Point(9, 108)
        Me.cmdBook.Name = "cmdBook"
        Me.cmdBook.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdBook.Size = New System.Drawing.Size(129, 33)
        Me.cmdBook.TabIndex = 4
        Me.cmdBook.Text = "Create &Time Tables "
        Me.cmdBook.UseVisualStyleBackColor = False
        '
        'lblFormTitle
        '
        Me.lblFormTitle.BackColor = System.Drawing.Color.Transparent
        Me.lblFormTitle.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblFormTitle.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.lblFormTitle.Font = New System.Drawing.Font("Verdana", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFormTitle.ForeColor = System.Drawing.Color.Gray
        Me.lblFormTitle.Location = New System.Drawing.Point(20, 15)
        Me.lblFormTitle.Name = "lblFormTitle"
        Me.lblFormTitle.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblFormTitle.Size = New System.Drawing.Size(223, 25)
        Me.lblFormTitle.TabIndex = 0
        Me.lblFormTitle.Text = "CREATE BUS BOOK"
        Me.lblFormTitle.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'DataGridView1
        '
        Me.DataGridView1.AllowUserToAddRows = False
        Me.DataGridView1.AllowUserToDeleteRows = False
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.LightYellow
        DataGridViewCellStyle1.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        DataGridViewCellStyle1.ForeColor = System.Drawing.Color.FromArgb(CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer), CType(CType(64, Byte), Integer))
        Me.DataGridView1.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle1
        Me.DataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.DataGridView1.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.Selected, Me.Route})
        Me.DataGridView1.Location = New System.Drawing.Point(20, 55)
        Me.DataGridView1.Name = "DataGridView1"
        Me.DataGridView1.Size = New System.Drawing.Size(267, 530)
        Me.DataGridView1.TabIndex = 8
        '
        'Selected
        '
        Me.Selected.HeaderText = ""
        Me.Selected.Name = "Selected"
        Me.Selected.Width = 50
        '
        'Route
        '
        DataGridViewCellStyle2.Font = New System.Drawing.Font("Verdana", 9.75!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Route.DefaultCellStyle = DataGridViewCellStyle2
        Me.Route.HeaderText = "Route"
        Me.Route.Name = "Route"
        Me.Route.ReadOnly = True
        Me.Route.Resizable = System.Windows.Forms.DataGridViewTriState.[True]
        Me.Route.SortMode = System.Windows.Forms.DataGridViewColumnSortMode.NotSortable
        Me.Route.Width = 150
        '
        'Panel1
        '
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel1.Controls.Add(Me.cmdSelectAll)
        Me.Panel1.Controls.Add(Me.cmdClearAll)
        Me.Panel1.Controls.Add(Me.cmdBook)
        Me.Panel1.Location = New System.Drawing.Point(330, 184)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(146, 152)
        Me.Panel1.TabIndex = 9
        '
        'cmdSelectFolder
        '
        Me.cmdSelectFolder.BackColor = System.Drawing.SystemColors.Control
        Me.cmdSelectFolder.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdSelectFolder.ForeColor = System.Drawing.Color.Black
        Me.cmdSelectFolder.Location = New System.Drawing.Point(340, 63)
        Me.cmdSelectFolder.Name = "cmdSelectFolder"
        Me.cmdSelectFolder.Size = New System.Drawing.Size(129, 33)
        Me.cmdSelectFolder.TabIndex = 5
        Me.cmdSelectFolder.Text = "&Select Folder"
        Me.cmdSelectFolder.UseVisualStyleBackColor = False
        '
        'ProgressBar1
        '
        Me.ProgressBar1.Location = New System.Drawing.Point(300, 561)
        Me.ProgressBar1.Name = "ProgressBar1"
        Me.ProgressBar1.Size = New System.Drawing.Size(455, 23)
        Me.ProgressBar1.TabIndex = 10
        Me.ProgressBar1.Visible = False
        '
        'lblProcess
        '
        Me.lblProcess.Font = New System.Drawing.Font("Verdana", 8.0!, System.Drawing.FontStyle.Italic, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblProcess.ForeColor = System.Drawing.SystemColors.GrayText
        Me.lblProcess.Location = New System.Drawing.Point(299, 535)
        Me.lblProcess.Name = "lblProcess"
        Me.lblProcess.Size = New System.Drawing.Size(456, 23)
        Me.lblProcess.TabIndex = 11
        Me.lblProcess.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        Me.lblProcess.Visible = False
        '
        'lblFolderDir
        '
        Me.lblFolderDir.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.lblFolderDir.Location = New System.Drawing.Point(297, 108)
        Me.lblFolderDir.Name = "lblFolderDir"
        Me.lblFolderDir.Size = New System.Drawing.Size(226, 25)
        Me.lblFolderDir.TabIndex = 12
        Me.lblFolderDir.Text = "Folder Location"
        Me.lblFolderDir.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        Me.lblFolderDir.UseWaitCursor = True
        Me.lblFolderDir.Visible = False
        '
        'frmRoute
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(791, 625)
        Me.Controls.Add(Me.lblFolderDir)
        Me.Controls.Add(Me.lblProcess)
        Me.Controls.Add(Me.ProgressBar1)
        Me.Controls.Add(Me.cmdSelectFolder)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.DataGridView1)
        Me.Controls.Add(Me.lblFormTitle)
        Me.Cursor = System.Windows.Forms.Cursors.Default
        Me.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Location = New System.Drawing.Point(354, 225)
        Me.Name = "frmRoute"
        Me.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        CType(Me.DataGridView1, System.ComponentModel.ISupportInitialize).EndInit()
        Me.Panel1.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub
#End Region
#Region "Upgrade Support "
    Private Shared m_vb6FormDefInstance As frmRoute
    Private Shared m_InitializingDefInstance As Boolean
    Public AppTitle As String
    Public AppName As String
    Public DestPath As String
    Public ExcelApp As Microsoft.Office.Interop.Excel.Application
    Public colStop As Collection 'collection of stops to store octa_id for each link_id
    Public arrLongPattern() As String 'array of route patterns that the end_place is the last timing point of the route
    Public arrPatternDesc(10, 3) As Object
    Public PatternCnt As Short
    Public GISPassingTimes As DataTable
    Dim ErrLog As Boolean

    Public Shared Property DefInstance() As frmRoute
        Get
            If m_vb6FormDefInstance Is Nothing OrElse m_vb6FormDefInstance.IsDisposed Then
                m_InitializingDefInstance = True
                m_vb6FormDefInstance = New frmRoute()
                m_InitializingDefInstance = False
            End If
            DefInstance = m_vb6FormDefInstance
        End Get
        Set
            m_vb6FormDefInstance = Value
        End Set
    End Property
#End Region
    'Dim GISPassingTimes As DataTable

    Private Sub cmdBook_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdBook.Click
        Dim strTmp As String = ""

        For Each row As DataGridViewRow In DataGridView1.Rows
            If row.Cells(0).Value <> 0 Then
                strTmp = strTmp & row.Cells(1).Value & ","
            End If
        Next row

        If strTmp = "" Then
            MsgBox("No route has been selected.", MsgBoxStyle.Information, AppTitle)
            Exit Sub
        ElseIf DestPath Is Nothing OrElse DestPath Is DBNull.Value Then
            MsgBox("Please select an output folder.", MsgBoxStyle.Information, AppTitle)
            Exit Sub
        Else
            If MsgBox("Create time tables of selected routes?", MsgBoxStyle.YesNo + MsgBoxStyle.Question, AppTitle) = MsgBoxResult.No Then Exit Sub
            strTmp = " (" & VB.Left(strTmp, Len(strTmp) - 1) & ")"
            Me.ProgressBar1.Visible = True
            Me.lblProcess.Visible = True
            Me.lblProcess.Text = "Processing Time Table..."
            CreateBook((DestPath), strTmp)
        End If

        Me.ProgressBar1.Visible = False
        Me.lblProcess.Visible = False

    End Sub

    Private Sub cmdClearAll_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdClearAll.Click

        For Each row As DataGridViewRow In DataGridView1.Rows
            row.Cells(0).Value = 0
        Next row

    End Sub

    Private Sub GridRteRead()
        Dim strSQL As String
        Dim rsRte As New ADODB.Recordset
        Dim i As Integer = 0

        On Error GoTo ErrHandling

        strSQL = "SELECT Route_ID AS Route, Route_ID "
        strSQL = strSQL & "From dbo.tblGISPassingTimes "
        strSQL = strSQL & "GROUP BY Route_ID, Route_ID "
        strSQL = strSQL & "ORDER BY Route"

        rsRte.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockReadOnly)
        Dim GISPassingTimes As New DataTable
        GISPassingTimes.Columns.Add("Selected", GetType(Integer))
        GISPassingTimes.Columns.Add("Route", GetType(String))

        Do While Not rsRte.EOF
            GISPassingTimes.Rows.Add(0, rsRte.Fields("route").Value)
            DataGridView1.Rows.Add(0, rsRte.Fields("route").Value)
            rsRte.MoveNext()
        Loop

        rsRte.Close()
        rsRte = Nothing
        Exit Sub
ErrHandling:
        MsgBox("Error accessing database." & vbCrLf & Err.Description, MsgBoxStyle.Exclamation, AppTitle)
    End Sub

    Private Sub cmdSelectAll_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdSelectAll.Click

        For Each row As DataGridViewRow In DataGridView1.Rows
            row.Cells(0).Value = 1
        Next row

    End Sub

    Private Sub frmRoute_Load(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load

        On Error GoTo ErrHandling
        Me.Text = AppTitle
        ProgressBar1.Visible = False

        GridRteRead()

        Exit Sub
ErrHandling:
        MsgBox("Form internal error. Unable to load form.", MsgBoxStyle.Exclamation, AppTitle)
        Me.Close()
    End Sub

    Sub CreateBook(ByRef excelPath As String, ByRef strSrch As String)
        Dim strSQL, LogFile As String
        Dim rsRouteDB As New ADODB.Recordset
        Dim strSQL2 As String

        'open Microsoft Excel application
        ExcelApp = New Microsoft.Office.Interop.Excel.Application
        ErrLog = False
        LogFile = VB6.GetPath & "\" & AppName & ".log"
        FileOpen(1, LogFile, OpenMode.Output)

        'all for each route day and direction(the original SQL lines)
        'for recordcount
        strSQL2 = "select distinct route_id, days, direction from dbo.tblGISPassingTimes "
        strSQL2 = strSQL2 & "where route_id is not null and days is not null and direction is not null "
        strSQL2 = strSQL2 & "and trip_id is not null and time is not null and place_id is not null AND Route_ID IN "
        strSQL2 = strSQL2 & strSrch

        ''make the books
        strSQL = "select route_id, days, direction, trip_id, time, place_id from dbo.tblGISPassingTimes "
        strSQL = strSQL & "where route_id is not null and days is not null and direction is not null "
        strSQL = strSQL & "and trip_id is not null and time is not null and place_id is not null AND Route_ID IN "
        strSQL = strSQL & strSrch
        strSQL = strSQL & " order by route_id, days, direction, trip_id, time"
        'End If

        On Error GoTo lblSelectErr
        rsRouteDB.Open(strSQL2, db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockOptimistic, ADODB.CommandTypeEnum.adCmdText)

        If rsRouteDB.BOF Then
            GoTo lblExit
        End If

        On Error GoTo 0

        rsRouteDB.Close()

        'read data source
        Dim RouteTable As clsRouteTable
        Dim curRouteID As String
        Dim curDays As Short
        Dim curDirection As Short
        Dim curTripID As String
        Dim cnt As Integer

        On Error GoTo lblSelectErr
        rsRouteDB.Open(strSQL, db)

        Dim TableCnt As Integer
        TableCnt = rsRouteDB.RecordCount

        Me.ProgressBar1.Minimum = 0
        Me.ProgressBar1.Value = 0
        Me.ProgressBar1.Maximum = TableCnt

        On Error GoTo 0
        cnt = 0
        While Not rsRouteDB.EOF
            cnt = cnt + 1
            'move progress bar
            Me.ProgressBar1.Value = Me.ProgressBar1.Value + 1

            If cnt = 1 Then
                'track current route table
                curRouteID = rsRouteDB.Fields("route_id").Value
                curDays = rsRouteDB.Fields("days").Value
                curDirection = rsRouteDB.Fields("direction").Value

                'track current trip
                curTripID = rsRouteDB.Fields("trip_id").Value

                'new RouteTable object
                RouteTable = New clsRouteTable
                RouteTable.RouteID = curRouteID
                RouteTable.Days = curDays
                RouteTable.Direction = curDirection

                ReadRouteStopsMDB(RouteTable)

                'add trip to Trips collection
                RouteTable.Trips.Add(curTripID)
            Else
                If Not (rsRouteDB.Fields("route_id").Value = curRouteID And rsRouteDB.Fields("days").Value = curDays And rsRouteDB.Fields("direction").Value = curDirection) Then 'end of current route table reached

                    'output current route table object
                    If Not WriteTable(RouteTable, excelPath) Then
                        GoTo lblExit
                    End If

                    'track current route table
                    curRouteID = rsRouteDB.Fields("route_id").Value
                    curDays = rsRouteDB.Fields("days").Value
                    curDirection = rsRouteDB.Fields("direction").Value

                    'track current trip
                    curTripID = rsRouteDB.Fields("trip_id").Value

                    'new RouteTable object
                    RouteTable = Nothing
                    RouteTable = New clsRouteTable
                    RouteTable.RouteID = curRouteID
                    RouteTable.Days = curDays
                    RouteTable.Direction = curDirection

                    ReadRouteStopsMDB(RouteTable)

                    'add trip to Trips collection
                    RouteTable.Trips.Add(curTripID)
                Else 'continue on the same route table
                    If rsRouteDB.Fields("trip_id").Value <> curTripID Then 'end of current trip reached
                        'track current trip
                        curTripID = rsRouteDB.Fields("trip_id").Value
                        'add trip in Trips collection
                        RouteTable.Trips.Add(curTripID)
                    End If
                End If
            End If

            Me.lblProcess.Text = "Processing Bus Book... Route: " & rsRouteDB.Fields("route_id").Value & " / Dir: " & rsRouteDB.Fields("direction").Value & " / Day: " & rsRouteDB.Fields("days").Value & ""

            'add stop to Stops collection if placeid does not already exist
            'if failed adding stop, then don't add to TimePoints collection
            RouteTable.Trips.Item(curTripID).TimePoints.Add(rsRouteDB.Fields("place_id").Value, rsRouteDB.Fields("time").Value)

            'next time point
            rsRouteDB.MoveNext()

        End While
        'output the last RouteTable object
        If Not WriteTable(RouteTable, excelPath) Then
            GoTo lblExit
        End If

        'Bus book geenrated successfully
        Me.ProgressBar1.Visible = False
        '    Unload frmroute
        If ErrLog Then
            If MsgBox("Time Tables Log Report generated. Please refer to log file " & LogFile & ".  Read log now?", MsgBoxStyle.YesNo + MsgBoxStyle.Information, "Time Tables Log") = MsgBoxResult.Yes Then
                FileClose(1)
                Shell("notepad.exe " & LogFile, AppWinStyle.NormalFocus)
            End If
        Else
            MsgBox("Time tables generated successfully in " & excelPath & ".", MsgBoxStyle.OkOnly + MsgBoxStyle.Information, AppTitle)
        End If
lblExit:
        'close route table cursor
        rsRouteDB.Close()
        rsRouteDB = Nothing

        'close error log
        FileClose(1)

        'close Excel application
        ExcelApp.Quit()
        ExcelApp = Nothing

        Exit Sub

lblSelectErr:
        MsgBox("Error querying database: GIS Passing times", MsgBoxStyle.Exclamation, AppTitle)
        ExcelApp.Quit()
        frmRoute.DefInstance.ProgressBar1.Visible = False
        FileClose(1)
        Exit Sub


    End Sub

    'Output Algorithm:
    '1.  Sort stops in the Stops collection of the RouteTable object by seq.
    '2.  Sort trips in the Trips collection of RouteTable object by calling Trip Sorting Algorithm.
    '3.  Output one trip at a time from Trips collection.
    '4.  Follow stops order for output.  Compare TimePoint.place_id of the current trip object to Stop.place_id, write TimePoint.time to file only when they match, write blank otherwise.
    '5.  Repeat from step 3 for next trip.

    Function WriteTable(ByRef rt As clsRouteTable, ByRef strPath As String) As Boolean

        Dim WorkBook As Excel._Workbook
        Dim WorkSheet As Excel._Worksheet
        Dim WorkSheet2 As Excel._Worksheet

        Dim s As clsStop
        Dim t As clsTrip
        Dim LastStop As String = ""

        Dim cell As String
        Dim colIndex, MaxColIndex As Short
        Dim rowIndex As Short
        Dim TpIndex, i As Integer

        Dim rs As New ADODB.Recordset
        Dim strSQL, vStr As String
        Dim CellValue, vTP As String
        Dim vDay, strFile, vDir As String

        Dim arrMark() As String
        Dim arrTP() As String

        Dim NiteOwl As Boolean

        'sort stops in the Stops collection
        If rt.Stops.Count = 0 Then 'no stop is contained in the trip
            PrintErr("No bus stop - route: " & rt.RouteID & " days: " & rt.Days & " Direction: " & rt.Direction)
            GoTo lblExit
        End If

        ReDim arrMark(rt.Stops.Count)
        ReDim arrTP(rt.Stops.Count)

        'sort trips in Trips collection
        rt.Trips.Sort((rt.Stops))

        'create new excel workbook
        WorkBook = ExcelApp.Workbooks.Add

        If WorkBook Is Nothing Then
            WriteTable = False
            MsgBox("Error creating MS Excel object.", MsgBoxStyle.Exclamation, AppTitle)
            Exit Function
        End If

        'write title and column header
        Dim strDir As String = ""
        Dim strDir2 As String = ""
        Dim strDays As String = ""
        Dim bColor As Integer

        WorkSheet2 = WorkBook.Worksheets.Add
        WorkSheet2.Name = "sheet2"

        'Set WorkSheet2 = ExcelApp.Worksheets("sheet2")
        WorkSheet2.Cells.HorizontalAlignment = Microsoft.Office.Interop.Excel.Constants.xlCenter
        WorkSheet2.Cells.Font.Name = "Arial"
        WorkSheet2.Cells.Font.Size = 8
        WorkSheet2.StandardWidth = 4
        NiteOwl = (rt.RouteID = "43" Or rt.RouteID = "50" Or rt.RouteID = "57" Or rt.RouteID = "60")

        Select Case rt.Direction
            Case 0
                strDir = "Northbound"
                strDir2 = "North"
            Case 1
                strDir = "Southbound"
                strDir2 = "South"
            Case 2
                strDir = "Eastbound"
                strDir2 = "East"
            Case 3
                strDir = "Westbound"
                strDir2 = "West"
            Case 4
                strDir = "Clockwise"
                strDir2 = strDir
            Case 5
                strDir = "Counter Clockwise"
                strDir2 = "Counterclockwise"
            Case Else
                PrintErr("Route: " & rt.RouteID & " Days: " & rt.Days & "Direction has invalid value: " & rt.Direction)
        End Select

        Select Case rt.Days
            Case 1
                strDays = "MONDAY-FRIDAY"
            Case 2
                strDays = "SATURDAY"
            Case 3
                strDays = "SUNDAY AND HOLIDAY"
            Case Else
                PrintErr("Route: " & rt.RouteID & " Direction: " & rt.Direction & "Days field has invalid value: " & rt.Days)
        End Select

        WorkSheet2.Range("A1").HorizontalAlignment = Microsoft.Office.Interop.Excel.Constants.xlLeft
        WorkSheet2.Range("A1").Font.Bold = True
        WorkSheet2.Range("A1").Font.Size = 18
        WorkSheet2.Range("A1").Value = "Route " & rt.RouteID
        WorkSheet2.Range("A2").HorizontalAlignment = Microsoft.Office.Interop.Excel.Constants.xlLeft
        WorkSheet2.Range("A2").Font.Bold = True
        WorkSheet2.Range("A2").Font.Size = 12
        WorkSheet2.Range("A2").Value = strDays & ": " & strDir
        WorkSheet2.Range("A3").HorizontalAlignment = Microsoft.Office.Interop.Excel.Constants.xlLeft
        WorkSheet2.Range("A3").Font.Bold = True
        WorkSheet2.Range("A3").Font.Size = 12

        WorkSheet = ExcelApp.Worksheets("sheet1")
        WorkSheet.Cells.HorizontalAlignment = Microsoft.Office.Interop.Excel.Constants.xlCenter
        WorkSheet.Cells.Font.Name = "Arial"
        WorkSheet.Cells.Font.Size = 8
        WorkSheet.StandardWidth = 4
        colIndex = 65
        WorkSheet.Rows._Default(1).RowHeight = 75.68
        For Each s In rt.Stops
            'replace onStreet & atStreet with Alias description if it is defined
            On Error GoTo lblSelectErr
            strSQL = "select alias from dbo.tblLandmarksAlias where place_id = '" & s.PlaceID & "'"
            rs.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenForwardOnly, ADODB.LockTypeEnum.adLockReadOnly)

            On Error GoTo 0
            If Not rs.EOF Then
                CellValue = rs.Fields("alias").Value
            Else
                CellValue = s.PlaceID
                PrintErr("Data Error: Unable to find alias for PlaceID " & s.PlaceID & " in Route " & rt.RouteID & ", Day " & rt.Days & ", Direction " & rt.Direction)
            End If
            rs.Close()
            'column headers
            cell = Chr(colIndex) & "1"
            WorkSheet.Range(cell).Orientation = 90
            WorkSheet.Range(cell).Value = CellValue
            WorkSheet.Range(cell).Borders(Microsoft.Office.Interop.Excel.XlBordersIndex.xlEdgeBottom).Weight = Microsoft.Office.Interop.Excel.XlBorderWeight.xlThin
            If colIndex > 65 Then
                WorkSheet.Range(cell).Borders(Microsoft.Office.Interop.Excel.XlBordersIndex.xlEdgeLeft).Weight = Microsoft.Office.Interop.Excel.XlBorderWeight.xlThin
                WorkSheet.Range(cell).Borders(Microsoft.Office.Interop.Excel.XlBordersIndex.xlEdgeBottom).Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.Black)
            End If
            arrTP(colIndex - 64) = s.PlaceID
            colIndex = colIndex + 1
        Next s

        strSQL = "SELECT * FROM dbo.tblBusRouteDescriptions WHERE ROUTE=" & rt.RouteID
        strSQL = strSQL & " AND DIRECTION=" & cV2Q_String(strDir2) & " AND DAYS=" & rt.Days
        On Error GoTo lblSelectErr
        rs.Open(strSQL, db)
        On Error GoTo 0
        If Not rs.EOF Then
            LastStop = rs.Fields("TO:").Value
        Else
            PrintErr("Data Error: Unable to find TO: value for Route " & rt.RouteID & ", Day " & rt.Days & ", Direction " & rt.Direction)
        End If
        rs.Close()

        WorkSheet2.Range("A3").Value = "TO: " & LastStop
        MaxColIndex = colIndex - 1
        'write trips
        rowIndex = 2
        bColor = RGB(255, 255, 255)
        For Each t In rt.Trips
            colIndex = 65
            TpIndex = 1
            vStr = ""
            If (rowIndex - 1) Mod 5 = 1 Then
                If bColor = RGB(255, 255, 255) Then
                    bColor = RGB(200, 200, 200)
                Else
                    bColor = RGB(255, 255, 255)
                End If
            End If
            WorkSheet.Range("A" & rowIndex & ".." & Chr(MaxColIndex) & rowIndex).Interior.Color = bColor
            WorkSheet.Rows._Default(rowIndex).RowHeight = 14 '12.75
            For Each s In rt.Stops
                cell = Chr(colIndex) & rowIndex
                If colIndex > 65 Then
                    WorkSheet.Range(cell).Borders(Microsoft.Office.Interop.Excel.XlBordersIndex.xlEdgeLeft).Weight = Microsoft.Office.Interop.Excel.XlBorderWeight.xlThin
                    WorkSheet.Range(cell).Borders(Microsoft.Office.Interop.Excel.XlBordersIndex.xlEdgeBottom).Color = System.Drawing.ColorTranslator.ToOle(System.Drawing.Color.Black)
                End If
                If TpIndex <= t.TimePoints.Count Then 'all timepoints have been listed
                    'instead of Exit For when TpIndex > Count, we want to run the code above to draw border
                    'Ignore any times from the passingtimes table that is not in the timepoint_seq or the missingtimepoints tables
                    Do While TpIndex <= t.TimePoints.Count
                        For i = colIndex - 64 To rt.Stops.Count
                            If t.TimePoints.Item(TpIndex).PlaceID = arrTP(i) Then Exit For
                        Next
                        If i > rt.Stops.Count Then
                            PrintErr("Invalid timepoint - " & t.TimePoints.Item(TpIndex).PlaceID & ":" & t.TimePoints.Item(TpIndex).time & " in Route " & rt.RouteID & ", Day " & rt.Days & ", Direction " & rt.Direction & ", Trip " & t.TripID)
                        Else
                            Exit Do
                        End If
                        TpIndex = TpIndex + 1
                    Loop
                    If TpIndex <= t.TimePoints.Count Then
                        If t.TimePoints.Item(TpIndex).PlaceID = s.PlaceID Then 'the trip route thru this stop
                            vStr = vStr & t.TimePoints.Item(TpIndex).PlaceID & ": " & CStr(t.TimePoints.Item(TpIndex).time) & ","
                            vTP = CStr(t.TimePoints.Item(TpIndex).time)
                            Select Case t.TimePoints.Item(TpIndex).time
                                Case Is < 1200
                                    'WorkSheet.Range(cell).Value = Left(vTP, Len(vTP) - 2) & ":" & Right(vTP, 2)
                                    WorkSheet.Range(cell).Value = vTP.Substring(0, Len(vTP) - 2) & ":" & vTP.Substring(Len(vTP) - 2, 2)
                                Case 1200 To 1259
                                    'WorkSheet.Range(cell).Value = Left(vTP, Len(vTP) - 2) & ":" & Right(vTP, 2)
                                    WorkSheet.Range(cell).Value = vTP.Substring(0, Len(vTP) - 2) & ":" & vTP.Substring(Len(vTP) - 2, 2)
                                    WorkSheet.Range(cell).Font.Bold = True
                                Case 1300 To 2359
                                    vTP = CStr(CShort(vTP) - 1200)
                                    'WorkSheet.Range(cell).Value = Left(vTP, Len(vTP) - 2) & ":" & Right(vTP, 2)
                                    WorkSheet.Range(cell).Value = vTP.Substring(0, Len(vTP) - 2) & ":" & vTP.Substring(Len(vTP) - 2, 2)
                                    WorkSheet.Range(cell).Font.Bold = True
                                Case 2400 To 2459
                                    vTP = CStr(CShort(vTP) - 1200)
                                    'WorkSheet.Range(cell).Value = Left(vTP, Len(vTP) - 2) & ":" & Right(vTP, 2)
                                    WorkSheet.Range(cell).Value = vTP.Substring(0, Len(vTP) - 2) & ":" & vTP.Substring(Len(vTP) - 2, 2)
                                Case Is >= 2500
                                    vTP = CStr(CShort(vTP) - 2400)
                                    'WorkSheet.Range(cell).Value = Left(vTP, Len(vTP) - 2) & ":" & Right(vTP, 2)
                                    WorkSheet.Range(cell).Value = vTP.Substring(0, Len(vTP) - 2) & ":" & vTP.Substring(Len(vTP) - 2, 2)
                            End Select
                            TpIndex = TpIndex + 1
                        End If 't.TimePoints.Item(TpIndex).PlaceID = s.PlaceID
                    End If
                End If 'TpIndex <= t.TimePoints.Count
                colIndex = colIndex + 1
            Next s
            If t.TimePoints.Count <> TpIndex - 1 Then
                For i = TpIndex To t.TimePoints.Count
                    vStr = vStr & t.TimePoints.Item(i).PlaceID & ": " & CStr(t.TimePoints.Item(i).time) & ","
                Next
                PrintErr("Data Error.  Route: " & rt.RouteID & ", Day: " & rt.Days & ", Direction: " & rt.Direction & ", Trip: " & t.TripID & " cannot be displayed correctly.")
                PrintErr("   " & vStr.Substring(0, Len(vStr) - 1))
            End If
            rowIndex = rowIndex + 1
        Next t

        Select Case rt.Days
            Case 1
                vDay = "mf"
            Case 2
                vDay = "sat"
            Case 3
                vDay = "sunh"
            Case Else
                vDay = ""
        End Select
        Select Case rt.Direction
            Case 0
                vDir = "_n"
            Case 1
                vDir = "_s"
            Case 2
                vDir = "_e"
            Case 3
                vDir = "_w"
            Case 4
                vDir = "_c"
            Case 5
                vDir = "_a"
            Case Else
                vDir = ""
        End Select
        'strFile = Right(CStr(1000 + CShort(rt.RouteID)), 3) & vDay & vDir & ".xlsx"
        strFile = CStr(1000 + CShort(rt.RouteID)).Substring(1, 3) & vDay & vDir & ".xlsx"
        If Dir(strPath & "\" & strFile) <> "" Then
            Kill(strPath & "\" & strFile)
        End If
        WorkSheet.PageSetup.LeftFooter = strPath & "\" & strFile
        WorkSheet2.PageSetup.LeftFooter = strPath & "\" & strFile
        WorkBook.SaveAs(strPath & "\" & strFile)
        WorkBook.Close()
        WorkBook = Nothing

lblExit:
        rs = Nothing
        WriteTable = True
        Exit Function

lblSelectErr:
        MsgBox("Error querying database:" & Chr(10) & Chr(13) & strSQL, MsgBoxStyle.Exclamation, AppTitle)
        WorkBook.Close()
        WorkBook = Nothing
        WriteTable = False
    End Function


    Sub ReadRouteStopsMDB(ByRef rt As clsRouteTable)

        Dim strSQL As String
        Dim rs As New ADODB.Recordset
        Dim rsStops As New ADODB.Recordset
        Dim sc As clsStops
        Dim s As clsStop
        Dim TblStatus As Boolean
        Dim BSeq, i, FSeq, vSeq As Integer
        Dim FPL, BPL As String

        Dim pid As String
        Dim sid As String
        Dim onSt As String
        Dim atSt As String
        Dim Seq As Short
        Dim dir_Renamed As String

        'There should never be a case where the MissingPt1 and MissingPt2 are both missing by route and direction.
        'This case should never occur.
        On Error GoTo ErrHandling

        TblStatus = False
        strSQL = "TRUNCATE TABLE dbo.tblRouteStops"
        db.Execute(strSQL)
        TblStatus = True
        strSQL = "INSERT INTO dbo.tblRouteStops SELECT * FROM dbo.tblTimePointSeq WHERE route=" & rt.RouteID & " AND dir=" & rt.Direction
        strSQL = strSQL & " AND place_id IS NOT NULL AND Seq IS NOT NULL AND DAYS=" & rt.Days
        db.Execute(strSQL)
        db.Execute("UPDATE dbo.tblRouteStops SET Seq = Seq * 10")
        strSQL = "SELECT * FROM dbo.tblMissingTimepoints WHERE route=" & rt.RouteID & " AND dir=" & rt.Direction
        strSQL = strSQL & " AND days=" & rt.Days & " AND place IS NOT NULL"
        rs.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockReadOnly)

        Do While Not rs.EOF
            vSeq = -1
            BPL = FilterNull((rs.Fields("back_place").Value))
            FPL = FilterNull((rs.Fields("forward_pl").Value))
            If BPL <> "" And FPL <> "" Then
                strSQL = "SELECT Seq FROM dbo.tblRouteStops WHERE Place_ID = " & cV2Q_String(BPL)
                rsStops.Open(strSQL, db)
                If rsStops.EOF Then
                    BSeq = -1
                Else
                    BSeq = rsStops.Fields("Seq").Value
                End If
                rsStops.Close()
                strSQL = "SELECT Seq FROM dbo.tblRouteStops WHERE Place_ID = " & cV2Q_String(FPL)
                rsStops.Open(strSQL, db)
                If rsStops.EOF Then
                    FSeq = -1
                Else
                    FSeq = rsStops.Fields("Seq").Value
                End If
                rsStops.Close()
                If FSeq <> -1 And BSeq <> -1 Then
                    vSeq = (BSeq + FSeq) / 2
                ElseIf FSeq <> -1 Then
                    vSeq = FSeq - 1
                ElseIf BSeq <> -1 Then
                    vSeq = BSeq + 1
                End If
            ElseIf FPL <> "" Then
                strSQL = "SELECT Seq FROM dbo.tblRouteStops WHERE Place_ID = " & cV2Q_String(FPL)
                rsStops.Open(strSQL, db)
                If Not rsStops.EOF Then vSeq = rsStops.Fields("Seq").Value - 1
                rsStops.Close()
            ElseIf BPL <> "" Then
                strSQL = "SELECT Seq FROM dbo.tblRouteStops WHERE Place_ID = " & cV2Q_String(BPL)
                rsStops.Open(strSQL, db)
                If Not rsStops.EOF Then vSeq = rsStops.Fields("Seq").Value + 1
                rsStops.Close()
            End If
            If vSeq < 0 Then
                PrintErr("Data error:" & "Unable to find sequence for Route: " & rt.RouteID & ", Direction: " & rt.Direction & ", place_id: " & rs.Fields("Place").Value)
            Else
                strSQL = "INSERT INTO dbo.tblRouteStops (route,dir,place_id,seq,days) VALUES (" & rt.RouteID & ","
                strSQL = strSQL & rt.Direction & "," & cV2Q_String((rs.Fields("place").Value)) & "," & vSeq & "," & rt.Days & ")"
                db.Execute(strSQL)
            End If
            rs.MoveNext()
        Loop

        rs.Close()
        sc = rt.Stops
        strSQL = "SELECT * FROM dbo.tblRouteStops ORDER BY Seq"
        rs.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockReadOnly)
        vSeq = -1
        Do While Not rs.EOF
            pid = rs.Fields("place_ID").Value
            sid = ""
            onSt = ""
            atSt = ""
            Seq = rs.Fields("Seq").Value
            If Seq <> vSeq Then
                sc.Add(pid, sid, onSt, atSt, Seq)
            Else
                PrintErr("Data error:" & "Duplicate timepoint sequence for Route: " & rt.RouteID & ", Direction: " & rt.Direction & ", place_id: " & pid)
            End If
            vSeq = Seq
            rs.MoveNext()
        Loop
        rs.Close()

        db.Execute("TRUNCATE TABLE dbo.tblRouteStops")
        TblStatus = False
        rs = Nothing
        rsStops = Nothing
        Exit Sub
ErrHandling:
        PrintErr("Error occurred while read timepoint sequence for Route: " & rt.RouteID & ", Direction: " & rt.Direction & ", Day: " & rt.Days)
        If rs.State = ADODB.ObjectStateEnum.adStateOpen Then rs.Close()
        If rsStops.State = ADODB.ObjectStateEnum.adStateOpen Then rsStops.Close()
        If TblStatus Then db.Execute("TRUNCATE TABLE dbo.tblRouteStops")
    End Sub

    Sub PrintErr(ByRef str_Renamed As String)
        PrintLine(1, str_Renamed)
        ErrLog = True
    End Sub

    Private Sub cmdSelectFolder_Click(sender As Object, e As EventArgs) Handles cmdSelectFolder.Click

        'frmDestination.DefInstance.Show()
        If (FolderBrowserDialog1.ShowDialog() = DialogResult.OK) Then
            lblFolderDir.Visible = True
            lblFolderDir.Text = FolderBrowserDialog1.SelectedPath
            DestPath = FolderBrowserDialog1.SelectedPath
        End If

    End Sub
End Class