﻿Public Class frmBusRouteDescription
    Private Sub frmBusRouteDescription_Load(sender As Object, e As EventArgs) Handles MyBase.Load

        Me.TblBusRouteDescriptionsTableAdapter.Fill(Me.BusRouteDescription.tblBusRouteDescriptions)

    End Sub

    Private Sub cmdSave_Click(sender As Object, e As EventArgs) Handles cmdSave.Click

        Try

            Me.Validate()
            Me.TblBusRouteDescriptionsBindingSource.EndEdit()
            Me.TblBusRouteDescriptionsTableAdapter.Update(Me.BusRouteDescription.tblBusRouteDescriptions)
            MsgBox("Update successful", MsgBoxStyle.Information, "Saved")

        Catch ex As Exception
            MsgBox(Err.Description)
        End Try

    End Sub

    Private Sub cmdAddNew_Click(sender As Object, e As EventArgs) Handles cmdAddNew.Click

        Me.TblBusRouteDescriptionsBindingSource.AddNew()
        Me.dgvBRDesc.DataSource = Me.TblBusRouteDescriptionsBindingSource

    End Sub

    Private Sub cmdDelete_Click(sender As Object, e As EventArgs) Handles cmdDelete.Click
        Dim result As DialogResult

        result = MsgBox("Do you want to delete this record?", MsgBoxStyle.YesNoCancel, "Confirm Delete")

        If result = Windows.Forms.DialogResult.Yes Then

            If dgvBRDesc.SelectedRows.Count > 0 Then
                dgvBRDesc.Rows.RemoveAt(Me.dgvBRDesc.CurrentRow.Index)
                Me.Validate()
                Me.TblBusRouteDescriptionsBindingSource.EndEdit()
                Me.TblBusRouteDescriptionsTableAdapter.Update(Me.BusRouteDescription)
                MsgBox("Delete successful", MsgBoxStyle.Information, "Deleted")
            Else
                MsgBox("You must select a row", MsgBoxStyle.Information, "Select")
            End If
        End If

    End Sub
End Class