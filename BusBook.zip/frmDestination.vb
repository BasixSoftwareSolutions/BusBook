Option Strict Off
Option Explicit On
Friend Class frmDestination
	Inherits System.Windows.Forms.Form
#Region "Windows Form Designer generated code "
	Public Sub New()
		MyBase.New()
		If m_vb6FormDefInstance Is Nothing Then
			If m_InitializingDefInstance Then
				m_vb6FormDefInstance = Me
			Else
				Try 
					'For the start-up form, the first instance created is the default instance.
					If System.Reflection.Assembly.GetExecutingAssembly.EntryPoint.DeclaringType Is Me.GetType Then
						m_vb6FormDefInstance = Me
					End If
				Catch
				End Try
			End If
		End If
		'This call is required by the Windows Form Designer.
		InitializeComponent()
	End Sub
	'Form overrides dispose to clean up the component list.
	Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
		If Disposing Then
			If Not components Is Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(Disposing)
	End Sub
	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer
	Public ToolTip1 As System.Windows.Forms.ToolTip
    Public WithEvents cmdGenerate As System.Windows.Forms.Button
    Public WithEvents cmdCancel As System.Windows.Forms.Button
    Public WithEvents dirDestination As Microsoft.VisualBasic.Compatibility.VB6.DirListBox
    Public WithEvents drvDestination As Microsoft.VisualBasic.Compatibility.VB6.DriveListBox
    Public WithEvents lblTitle As System.Windows.Forms.Label
    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmDestination))
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.cmdGenerate = New System.Windows.Forms.Button()
        Me.cmdCancel = New System.Windows.Forms.Button()
        Me.dirDestination = New Microsoft.VisualBasic.Compatibility.VB6.DirListBox()
        Me.drvDestination = New Microsoft.VisualBasic.Compatibility.VB6.DriveListBox()
        Me.lblTitle = New System.Windows.Forms.Label()
        Me.SuspendLayout()
        '
        'cmdGenerate
        '
        Me.cmdGenerate.BackColor = System.Drawing.SystemColors.Control
        Me.cmdGenerate.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdGenerate.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdGenerate.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdGenerate.Location = New System.Drawing.Point(36, 211)
        Me.cmdGenerate.Name = "cmdGenerate"
        Me.cmdGenerate.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdGenerate.Size = New System.Drawing.Size(81, 33)
        Me.cmdGenerate.TabIndex = 2
        Me.cmdGenerate.Text = "&Ok"
        Me.cmdGenerate.UseVisualStyleBackColor = False
        '
        'cmdCancel
        '
        Me.cmdCancel.BackColor = System.Drawing.SystemColors.Control
        Me.cmdCancel.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdCancel.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdCancel.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdCancel.Location = New System.Drawing.Point(144, 211)
        Me.cmdCancel.Name = "cmdCancel"
        Me.cmdCancel.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdCancel.Size = New System.Drawing.Size(81, 33)
        Me.cmdCancel.TabIndex = 3
        Me.cmdCancel.Text = "&Cancel"
        Me.cmdCancel.UseVisualStyleBackColor = False
        '
        'dirDestination
        '
        Me.dirDestination.BackColor = System.Drawing.SystemColors.Window
        Me.dirDestination.Cursor = System.Windows.Forms.Cursors.Default
        Me.dirDestination.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.dirDestination.ForeColor = System.Drawing.SystemColors.WindowText
        Me.dirDestination.FormattingEnabled = True
        Me.dirDestination.IntegralHeight = False
        Me.dirDestination.Location = New System.Drawing.Point(16, 66)
        Me.dirDestination.Name = "dirDestination"
        Me.dirDestination.Size = New System.Drawing.Size(225, 126)
        Me.dirDestination.TabIndex = 1
        '
        'drvDestination
        '
        Me.drvDestination.BackColor = System.Drawing.SystemColors.Window
        Me.drvDestination.Cursor = System.Windows.Forms.Cursors.Default
        Me.drvDestination.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.drvDestination.ForeColor = System.Drawing.SystemColors.WindowText
        Me.drvDestination.FormattingEnabled = True
        Me.drvDestination.Location = New System.Drawing.Point(16, 42)
        Me.drvDestination.Name = "drvDestination"
        Me.drvDestination.Size = New System.Drawing.Size(225, 21)
        Me.drvDestination.TabIndex = 0
        '
        'lblTitle
        '
        Me.lblTitle.BackColor = System.Drawing.Color.Transparent
        Me.lblTitle.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblTitle.Font = New System.Drawing.Font("Verdana", 12.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblTitle.ForeColor = System.Drawing.SystemColors.ControlDarkDark
        Me.lblTitle.Location = New System.Drawing.Point(16, 9)
        Me.lblTitle.Name = "lblTitle"
        Me.lblTitle.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblTitle.Size = New System.Drawing.Size(225, 25)
        Me.lblTitle.TabIndex = 4
        Me.lblTitle.Text = "Select Output Folder"
        Me.lblTitle.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'frmDestination
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(266, 256)
        Me.Controls.Add(Me.cmdGenerate)
        Me.Controls.Add(Me.cmdCancel)
        Me.Controls.Add(Me.dirDestination)
        Me.Controls.Add(Me.drvDestination)
        Me.Controls.Add(Me.lblTitle)
        Me.Cursor = System.Windows.Forms.Cursors.Default
        Me.Font = New System.Drawing.Font("Arial", 8.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.Fixed3D
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Location = New System.Drawing.Point(4, 23)
        Me.Name = "frmDestination"
        Me.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.ResumeLayout(False)

    End Sub
#End Region
#Region "Upgrade Support "
    Private Shared m_vb6FormDefInstance As frmDestination
	Private Shared m_InitializingDefInstance As Boolean
	Public Shared Property DefInstance() As frmDestination
		Get
			If m_vb6FormDefInstance Is Nothing OrElse m_vb6FormDefInstance.IsDisposed Then
				m_InitializingDefInstance = True
				m_vb6FormDefInstance = New frmDestination()
				m_InitializingDefInstance = False
			End If
			DefInstance = m_vb6FormDefInstance
		End Get
		Set
			m_vb6FormDefInstance = Value
		End Set
	End Property
#End Region 
	
	Public DefaultDrive As String
    Public DefaultPath As String

    Private Sub cmdCancel_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdCancel.Click

        Me.Close()

    End Sub

    Private Sub cmdGenerate_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdGenerate.Click
		Dim strMsg As String
		Dim rs As New ADODB.Recordset
		
		On Error GoTo ErrHandler

        If DestPath = vbNullString Then DestPath = dirDestination.Path

        Me.Close()

        Exit Sub

ErrHandler: 
		Me.Cursor = System.Windows.Forms.Cursors.Default
		MsgBox(Err.Source & ": " & Err.Description, MsgBoxStyle.Exclamation, System.Reflection.Assembly.GetExecutingAssembly.GetName.Name)
		
	End Sub
	
	Private Sub dirDestination_Change(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles dirDestination.Change
		DestPath = dirDestination.Path
	End Sub
	
	Private Sub drvDestination_SelectedIndexChanged(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles drvDestination.SelectedIndexChanged
		On Error GoTo lblError
		dirDestination.Path = drvDestination.Drive
		Exit Sub
lblError: 
		MsgBox("Drive is inaccessible.", MsgBoxStyle.Exclamation)
		drvDestination.Drive = DefaultDrive
		dirDestination.Path = DefaultPath
	End Sub

    Private Sub frmDestination_Load(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load

        DefaultDrive = drvDestination.Drive
        DefaultPath = dirDestination.Path

    End Sub

End Class