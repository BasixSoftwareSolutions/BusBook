﻿<Global.Microsoft.VisualBasic.CompilerServices.DesignerGenerated()> _
Partial Class frmBusRouteDescription
    Inherits System.Windows.Forms.Form

    'Form overrides dispose to clean up the component list.
    <System.Diagnostics.DebuggerNonUserCode()> _
    Protected Overrides Sub Dispose(ByVal disposing As Boolean)
        Try
            If disposing AndAlso components IsNot Nothing Then
                components.Dispose()
            End If
        Finally
            MyBase.Dispose(disposing)
        End Try
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    <System.Diagnostics.DebuggerStepThrough()> _
    Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim DataGridViewCellStyle1 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle2 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle3 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle4 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Dim DataGridViewCellStyle5 As System.Windows.Forms.DataGridViewCellStyle = New System.Windows.Forms.DataGridViewCellStyle()
        Me.dgvBRDesc = New System.Windows.Forms.DataGridView()
        Me.lblFormTitle = New System.Windows.Forms.Label()
        Me.Label1 = New System.Windows.Forms.Label()
        Me.Label4 = New System.Windows.Forms.Label()
        Me.Label3 = New System.Windows.Forms.Label()
        Me.Label2 = New System.Windows.Forms.Label()
        Me.Label12 = New System.Windows.Forms.Label()
        Me.BusRouteDescription = New BusBook.BusRouteDescription()
        Me.TblBusRouteDescriptionsBindingSource = New System.Windows.Forms.BindingSource(Me.components)
        Me.TblBusRouteDescriptionsTableAdapter = New BusBook.BusRouteDescriptionTableAdapters.tblBusRouteDescriptionsTableAdapter()
        Me.IDDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.ROUTEDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DAYSDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DESCRIPTIONDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.DIRECTIONDataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.TODataGridViewTextBoxColumn = New System.Windows.Forms.DataGridViewTextBoxColumn()
        Me.cmdDelete = New System.Windows.Forms.Button()
        Me.cmdSave = New System.Windows.Forms.Button()
        Me.cmdAddNew = New System.Windows.Forms.Button()
        CType(Me.dgvBRDesc, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.BusRouteDescription, System.ComponentModel.ISupportInitialize).BeginInit()
        CType(Me.TblBusRouteDescriptionsBindingSource, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'dgvBRDesc
        '
        DataGridViewCellStyle1.BackColor = System.Drawing.Color.LightYellow
        Me.dgvBRDesc.AlternatingRowsDefaultCellStyle = DataGridViewCellStyle1
        Me.dgvBRDesc.AutoGenerateColumns = False
        Me.dgvBRDesc.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize
        Me.dgvBRDesc.Columns.AddRange(New System.Windows.Forms.DataGridViewColumn() {Me.IDDataGridViewTextBoxColumn, Me.ROUTEDataGridViewTextBoxColumn, Me.DAYSDataGridViewTextBoxColumn, Me.DESCRIPTIONDataGridViewTextBoxColumn, Me.DIRECTIONDataGridViewTextBoxColumn, Me.TODataGridViewTextBoxColumn})
        Me.dgvBRDesc.DataSource = Me.TblBusRouteDescriptionsBindingSource
        Me.dgvBRDesc.Location = New System.Drawing.Point(20, 55)
        Me.dgvBRDesc.MultiSelect = False
        Me.dgvBRDesc.Name = "dgvBRDesc"
        Me.dgvBRDesc.ScrollBars = System.Windows.Forms.ScrollBars.Vertical
        Me.dgvBRDesc.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect
        Me.dgvBRDesc.Size = New System.Drawing.Size(856, 530)
        Me.dgvBRDesc.TabIndex = 0
        '
        'lblFormTitle
        '
        Me.lblFormTitle.BackColor = System.Drawing.Color.Transparent
        Me.lblFormTitle.Cursor = System.Windows.Forms.Cursors.Default
        Me.lblFormTitle.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.lblFormTitle.Font = New System.Drawing.Font("Calibri Light", 20.0!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.lblFormTitle.ForeColor = System.Drawing.Color.White
        Me.lblFormTitle.Location = New System.Drawing.Point(20, 9)
        Me.lblFormTitle.Name = "lblFormTitle"
        Me.lblFormTitle.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.lblFormTitle.Size = New System.Drawing.Size(332, 46)
        Me.lblFormTitle.TabIndex = 2
        Me.lblFormTitle.Text = "Bus Route Descriptions"
        Me.lblFormTitle.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.Cursor = System.Windows.Forms.Cursors.Default
        Me.Label1.FlatStyle = System.Windows.Forms.FlatStyle.Flat
        Me.Label1.Font = New System.Drawing.Font("Verdana", 14.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label1.ForeColor = System.Drawing.Color.Gray
        Me.Label1.Location = New System.Drawing.Point(20, 15)
        Me.Label1.Name = "Label1"
        Me.Label1.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.Label1.Size = New System.Drawing.Size(611, 25)
        Me.Label1.TabIndex = 4
        Me.Label1.Text = "BUS ROUTE DESCRIPTION"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label4
        '
        Me.Label4.AutoSize = True
        Me.Label4.Location = New System.Drawing.Point(724, 601)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(66, 13)
        Me.Label4.TabIndex = 33
        Me.Label4.Text = "2 - Satudays"
        '
        'Label3
        '
        Me.Label3.AutoSize = True
        Me.Label3.Location = New System.Drawing.Point(796, 601)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(63, 13)
        Me.Label3.TabIndex = 32
        Me.Label3.Text = "3 - Sundays"
        '
        'Label2
        '
        Me.Label2.AutoSize = True
        Me.Label2.Location = New System.Drawing.Point(645, 601)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(73, 13)
        Me.Label2.TabIndex = 31
        Me.Label2.Text = "1 - Weekdays"
        '
        'Label12
        '
        Me.Label12.AutoSize = True
        Me.Label12.Font = New System.Drawing.Font("Arial", 8.25!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Label12.Location = New System.Drawing.Point(603, 600)
        Me.Label12.Name = "Label12"
        Me.Label12.Size = New System.Drawing.Size(36, 14)
        Me.Label12.TabIndex = 30
        Me.Label12.Text = "Days:"
        '
        'BusRouteDescription
        '
        Me.BusRouteDescription.DataSetName = "BusRouteDescription"
        Me.BusRouteDescription.SchemaSerializationMode = System.Data.SchemaSerializationMode.IncludeSchema
        '
        'TblBusRouteDescriptionsBindingSource
        '
        Me.TblBusRouteDescriptionsBindingSource.DataMember = "tblBusRouteDescriptions"
        Me.TblBusRouteDescriptionsBindingSource.DataSource = Me.BusRouteDescription
        '
        'TblBusRouteDescriptionsTableAdapter
        '
        Me.TblBusRouteDescriptionsTableAdapter.ClearBeforeFill = True
        '
        'IDDataGridViewTextBoxColumn
        '
        Me.IDDataGridViewTextBoxColumn.DataPropertyName = "ID"
        DataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.IDDataGridViewTextBoxColumn.DefaultCellStyle = DataGridViewCellStyle2
        Me.IDDataGridViewTextBoxColumn.HeaderText = "ID"
        Me.IDDataGridViewTextBoxColumn.Name = "IDDataGridViewTextBoxColumn"
        Me.IDDataGridViewTextBoxColumn.ReadOnly = True
        Me.IDDataGridViewTextBoxColumn.Width = 75
        '
        'ROUTEDataGridViewTextBoxColumn
        '
        Me.ROUTEDataGridViewTextBoxColumn.DataPropertyName = "ROUTE"
        DataGridViewCellStyle3.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.ROUTEDataGridViewTextBoxColumn.DefaultCellStyle = DataGridViewCellStyle3
        Me.ROUTEDataGridViewTextBoxColumn.HeaderText = "ROUTE"
        Me.ROUTEDataGridViewTextBoxColumn.Name = "ROUTEDataGridViewTextBoxColumn"
        Me.ROUTEDataGridViewTextBoxColumn.Width = 75
        '
        'DAYSDataGridViewTextBoxColumn
        '
        Me.DAYSDataGridViewTextBoxColumn.DataPropertyName = "DAYS"
        DataGridViewCellStyle4.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.DAYSDataGridViewTextBoxColumn.DefaultCellStyle = DataGridViewCellStyle4
        Me.DAYSDataGridViewTextBoxColumn.HeaderText = "DAYS"
        Me.DAYSDataGridViewTextBoxColumn.Name = "DAYSDataGridViewTextBoxColumn"
        Me.DAYSDataGridViewTextBoxColumn.Width = 75
        '
        'DESCRIPTIONDataGridViewTextBoxColumn
        '
        Me.DESCRIPTIONDataGridViewTextBoxColumn.DataPropertyName = "DESCRIPTION"
        Me.DESCRIPTIONDataGridViewTextBoxColumn.HeaderText = "DESCRIPTION"
        Me.DESCRIPTIONDataGridViewTextBoxColumn.Name = "DESCRIPTIONDataGridViewTextBoxColumn"
        Me.DESCRIPTIONDataGridViewTextBoxColumn.Width = 250
        '
        'DIRECTIONDataGridViewTextBoxColumn
        '
        Me.DIRECTIONDataGridViewTextBoxColumn.DataPropertyName = "DIRECTION"
        DataGridViewCellStyle5.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter
        Me.DIRECTIONDataGridViewTextBoxColumn.DefaultCellStyle = DataGridViewCellStyle5
        Me.DIRECTIONDataGridViewTextBoxColumn.HeaderText = "DIRECTION"
        Me.DIRECTIONDataGridViewTextBoxColumn.Name = "DIRECTIONDataGridViewTextBoxColumn"
        Me.DIRECTIONDataGridViewTextBoxColumn.Width = 75
        '
        'TODataGridViewTextBoxColumn
        '
        Me.TODataGridViewTextBoxColumn.DataPropertyName = "TO:"
        Me.TODataGridViewTextBoxColumn.HeaderText = "TO:"
        Me.TODataGridViewTextBoxColumn.Name = "TODataGridViewTextBoxColumn"
        Me.TODataGridViewTextBoxColumn.Width = 250
        '
        'cmdDelete
        '
        Me.cmdDelete.Image = Global.BusBook.My.Resources.Resources.DeleteEvent_16x
        Me.cmdDelete.Location = New System.Drawing.Point(115, 595)
        Me.cmdDelete.Name = "cmdDelete"
        Me.cmdDelete.Size = New System.Drawing.Size(75, 24)
        Me.cmdDelete.TabIndex = 36
        Me.cmdDelete.Text = "Delete"
        Me.cmdDelete.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.cmdDelete.UseVisualStyleBackColor = True
        '
        'cmdSave
        '
        Me.cmdSave.Image = Global.BusBook.My.Resources.Resources.Save_16x_32
        Me.cmdSave.Location = New System.Drawing.Point(196, 595)
        Me.cmdSave.Name = "cmdSave"
        Me.cmdSave.Size = New System.Drawing.Size(97, 24)
        Me.cmdSave.TabIndex = 35
        Me.cmdSave.Text = "Save Record"
        Me.cmdSave.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.cmdSave.UseVisualStyleBackColor = True
        '
        'cmdAddNew
        '
        Me.cmdAddNew.Image = Global.BusBook.My.Resources.Resources.Add_thin_10x_16x
        Me.cmdAddNew.Location = New System.Drawing.Point(26, 595)
        Me.cmdAddNew.Name = "cmdAddNew"
        Me.cmdAddNew.Size = New System.Drawing.Size(83, 24)
        Me.cmdAddNew.TabIndex = 34
        Me.cmdAddNew.Text = "Add New"
        Me.cmdAddNew.TextImageRelation = System.Windows.Forms.TextImageRelation.ImageBeforeText
        Me.cmdAddNew.UseVisualStyleBackColor = True
        '
        'frmBusRouteDescription
        '
        Me.AutoScaleDimensions = New System.Drawing.SizeF(6.0!, 13.0!)
        Me.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(899, 626)
        Me.Controls.Add(Me.cmdDelete)
        Me.Controls.Add(Me.cmdSave)
        Me.Controls.Add(Me.cmdAddNew)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.Label12)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.lblFormTitle)
        Me.Controls.Add(Me.dgvBRDesc)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None
        Me.Name = "frmBusRouteDescription"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen
        Me.Text = "Bus Route Description"
        CType(Me.dgvBRDesc, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.BusRouteDescription, System.ComponentModel.ISupportInitialize).EndInit()
        CType(Me.TblBusRouteDescriptionsBindingSource, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)
        Me.PerformLayout()

    End Sub

    Friend WithEvents dgvBRDesc As DataGridView
    Public WithEvents lblFormTitle As Label
    Public WithEvents Label1 As Label
    Friend WithEvents Label4 As Label
    Friend WithEvents Label3 As Label
    Friend WithEvents Label2 As Label
    Friend WithEvents Label12 As Label
    Friend WithEvents cmdAddNew As Button
    Friend WithEvents cmdSave As Button
    Friend WithEvents cmdDelete As Button
    Friend WithEvents BusRouteDescription As BusRouteDescription
    Friend WithEvents TblBusRouteDescriptionsBindingSource As BindingSource
    Friend WithEvents TblBusRouteDescriptionsTableAdapter As BusRouteDescriptionTableAdapters.tblBusRouteDescriptionsTableAdapter
    Friend WithEvents IDDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents ROUTEDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents DAYSDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents DESCRIPTIONDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents DIRECTIONDataGridViewTextBoxColumn As DataGridViewTextBoxColumn
    Friend WithEvents TODataGridViewTextBoxColumn As DataGridViewTextBoxColumn
End Class
