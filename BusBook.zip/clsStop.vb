Option Strict Off
Option Explicit On
Friend Class clsStop
	
	Private m_PlaceID As String
	Private m_StopNo As String
	Private m_OnStreet As String
	Private m_AtStreet As String
	Private m_Seq As Short
	
	
	Public Property PlaceID() As String
		Get
			PlaceID = m_PlaceID
		End Get
		Set(ByVal Value As String)
			m_PlaceID = Value
		End Set
	End Property
	
	Public Property StopNo() As String
		Get
			StopNo = m_StopNo
		End Get
		Set(ByVal Value As String)
			m_StopNo = Value
		End Set
	End Property
	
	
	Public Property OnStreet() As String
		Get
			OnStreet = m_OnStreet
		End Get
		Set(ByVal Value As String)
			m_OnStreet = Value
		End Set
	End Property
	
	
	Public Property AtStreet() As String
		Get
			AtStreet = m_AtStreet
		End Get
		Set(ByVal Value As String)
			m_AtStreet = Value
		End Set
	End Property
	
	
	Public Property Seq() As Short
		Get
			Seq = m_Seq
		End Get
		Set(ByVal Value As Short)
			m_Seq = Value
		End Set
	End Property
End Class