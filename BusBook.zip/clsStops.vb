Option Strict Off
Option Explicit On
Friend Class clsStops
	Implements System.Collections.IEnumerable
    'clsStops is a wrapper of collection class.
    'It works like collection, except it only contaisn one type of objects.
    'Its Add method automatically creates a Stop object.

    Private m_Stops As Collection
	
	Public ReadOnly Property Count() As Integer
		Get
			Count = m_Stops.Count()
		End Get
	End Property
	
	Public ReadOnly Property Item(ByVal index As String) As Object
		Get
            Item = m_Stops.Item(index)
        End Get
	End Property
	
	'UPGRADE_NOTE: NewEnum property was commented out. Click for more: 'ms-help://MS.VSCC.2003/commoner/redir/redirect.htm?keyword="vbup1054"'
	'Public ReadOnly Property NewEnum() As stdole.IUnknown
		'Get
			'NewEnum = m_Stops._NewEnum
		'End Get
	'End Property
	
	Public Function GetEnumerator() As System.Collections.IEnumerator Implements System.Collections.IEnumerable.GetEnumerator
        GetEnumerator = m_Stops.GetEnumerator
    End Function
	
	Public Sub Add(ByRef pid As String, ByRef sid As String, ByRef onSt As String, ByRef atSt As String, ByRef Seq As Short)
		Dim s As New clsStop
		s.PlaceID = pid
		s.StopNo = sid
		s.OnStreet = onSt
		s.AtStreet = atSt
		s.Seq = Seq
		m_Stops.Add(s, CStr(Seq))
	End Sub
	
	Public Sub Remove(ByRef index As String)
		m_Stops.Remove(index)
	End Sub
	
	Public Sub Sort()
		Dim arrSeq() As Short
		Dim s As clsStop
		Dim i As Short
		Dim j As Short
		Dim tmp As Short
		Dim NewStops As New Collection 'sorted copy of m_stops

        'store seq into an array
        ReDim arrSeq(m_Stops.Count())
        i = 1
		For	Each s In m_Stops
			arrSeq(i) = s.Seq
			i = i + 1
		Next s
		
		'sort arrSeq()
		For i = 1 To m_Stops.Count() - 1
			For j = i + 1 To m_Stops.Count()
				If arrSeq(j) < arrSeq(i) Then
					tmp = arrSeq(i)
					arrSeq(i) = arrSeq(j)
					arrSeq(j) = tmp
				End If
			Next j
		Next i
		
		'create new collection
		For i = 1 To m_Stops.Count()
			NewStops.Add(m_Stops.Item(CStr(arrSeq(i))), CStr(arrSeq(i)))
		Next i
        m_Stops = Nothing
        m_Stops = NewStops
	End Sub

    Private Sub Class_Initialize_Renamed()
        m_Stops = New Collection
    End Sub
    Public Sub New()
		MyBase.New()
		Class_Initialize_Renamed()
	End Sub

    Private Sub Class_Terminate_Renamed()
        m_Stops = Nothing
    End Sub
    Protected Overrides Sub Finalize()
		Class_Terminate_Renamed()
		MyBase.Finalize()
	End Sub
End Class