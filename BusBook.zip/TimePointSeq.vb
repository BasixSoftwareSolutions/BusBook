﻿Partial Class TimePointSeq
    Partial Public Class tblTimepointSeqDataTable
    End Class
End Class
