Option Strict Off
Option Explicit On
Friend Class frmQAQC
	Inherits System.Windows.Forms.Form
#Region "Windows Form Designer generated code "
	Public Sub New()
		MyBase.New()
		If m_vb6FormDefInstance Is Nothing Then
			If m_InitializingDefInstance Then
				m_vb6FormDefInstance = Me
			Else
				Try 
					'For the start-up form, the first instance created is the default instance.
					If System.Reflection.Assembly.GetExecutingAssembly.EntryPoint.DeclaringType Is Me.GetType Then
						m_vb6FormDefInstance = Me
					End If
				Catch
				End Try
			End If
		End If
		'This call is required by the Windows Form Designer.
		InitializeComponent()
	End Sub
	'Form overrides dispose to clean up the component list.
	Protected Overloads Overrides Sub Dispose(ByVal Disposing As Boolean)
		If Disposing Then
			If Not components Is Nothing Then
				components.Dispose()
			End If
		End If
		MyBase.Dispose(Disposing)
	End Sub
	'Required by the Windows Form Designer
	Private components As System.ComponentModel.IContainer
	Public ToolTip1 As System.Windows.Forms.ToolTip
	Public WithEvents cmdPrint As System.Windows.Forms.Button
	Public WithEvents cmdClose As System.Windows.Forms.Button
	Public WithEvents tdbgRoute As AxTrueOleDBGrid60.AxTDBGrid
	'NOTE: The following procedure is required by the Windows Form Designer
	'It can be modified using the Windows Form Designer.
	'Do not modify it using the code editor.
	<System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container()
        Dim resources As System.ComponentModel.ComponentResourceManager = New System.ComponentModel.ComponentResourceManager(GetType(frmQAQC))
        Me.ToolTip1 = New System.Windows.Forms.ToolTip(Me.components)
        Me.cmdPrint = New System.Windows.Forms.Button()
        Me.cmdClose = New System.Windows.Forms.Button()
        Me.tdbgRoute = New AxTrueOleDBGrid60.AxTDBGrid()
        CType(Me.tdbgRoute, System.ComponentModel.ISupportInitialize).BeginInit()
        Me.SuspendLayout()
        '
        'cmdPrint
        '
        Me.cmdPrint.BackColor = System.Drawing.SystemColors.Control
        Me.cmdPrint.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdPrint.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdPrint.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdPrint.Location = New System.Drawing.Point(336, 472)
        Me.cmdPrint.Name = "cmdPrint"
        Me.cmdPrint.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdPrint.Size = New System.Drawing.Size(73, 25)
        Me.cmdPrint.TabIndex = 1
        Me.cmdPrint.Text = "&Print"
        Me.cmdPrint.UseVisualStyleBackColor = False
        '
        'cmdClose
        '
        Me.cmdClose.BackColor = System.Drawing.SystemColors.Control
        Me.cmdClose.Cursor = System.Windows.Forms.Cursors.Default
        Me.cmdClose.Font = New System.Drawing.Font("Verdana", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.cmdClose.ForeColor = System.Drawing.SystemColors.ControlText
        Me.cmdClose.Location = New System.Drawing.Point(432, 472)
        Me.cmdClose.Name = "cmdClose"
        Me.cmdClose.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.cmdClose.Size = New System.Drawing.Size(73, 25)
        Me.cmdClose.TabIndex = 2
        Me.cmdClose.Text = "&Close"
        Me.cmdClose.UseVisualStyleBackColor = False
        '
        'tdbgRoute
        '
        'Me.tdbgRoute.DataSource = Nothing
        Me.tdbgRoute.Location = New System.Drawing.Point(8, 16)
        Me.tdbgRoute.Name = "tdbgRoute"
        Me.tdbgRoute.OcxState = CType(resources.GetObject("tdbgRoute.OcxState"), System.Windows.Forms.AxHost.State)
        Me.tdbgRoute.Size = New System.Drawing.Size(505, 441)
        Me.tdbgRoute.TabIndex = 0
        '
        'frmQAQC
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.BackColor = System.Drawing.Color.Cornsilk
        Me.ClientSize = New System.Drawing.Size(526, 511)
        Me.Controls.Add(Me.cmdPrint)
        Me.Controls.Add(Me.cmdClose)
        Me.Controls.Add(Me.tdbgRoute)
        Me.Cursor = System.Windows.Forms.Cursors.Default
        Me.Font = New System.Drawing.Font("Times New Roman", 8.25!, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.Location = New System.Drawing.Point(153, 185)
        Me.Name = "frmQAQC"
        Me.RightToLeft = System.Windows.Forms.RightToLeft.No
        Me.StartPosition = System.Windows.Forms.FormStartPosition.Manual
        Me.Text = "Time Tables QA/QC Comparison"
        CType(Me.tdbgRoute, System.ComponentModel.ISupportInitialize).EndInit()
        Me.ResumeLayout(False)

    End Sub
#End Region
#Region "Upgrade Support "
    Private Shared m_vb6FormDefInstance As frmQAQC
	Private Shared m_InitializingDefInstance As Boolean
	Public Shared Property DefInstance() As frmQAQC
		Get
			If m_vb6FormDefInstance Is Nothing OrElse m_vb6FormDefInstance.IsDisposed Then
				m_InitializingDefInstance = True
				m_vb6FormDefInstance = New frmQAQC()
				m_InitializingDefInstance = False
			End If
			DefInstance = m_vb6FormDefInstance
		End Get
		Set
			m_vb6FormDefInstance = Value
		End Set
	End Property
#End Region 
	Dim xaRoute As New XArrayDBObject.XArrayDB
	
	Private Sub GridRouteInit()
		Dim vItem As New TrueOleDBGrid60.ValueItem
		Dim C As TrueOleDBGrid60.Column
		Dim i As Short
		
		On Error GoTo ErrHandling
		With tdbgRoute.Columns
			While .Count > 0
				.Remove(0)
			End While
			For i = 0 To 3
				C = .Add(i)
				C.Visible = True
			Next i
		End With
		With tdbgRoute
			.AllowRowSizing = False
			.AllowColSelect = False
			.RecordSelectors = False
			.AllowUpdate = False
		End With
		
		With tdbgRoute.Columns(0)
			.Caption = "Route"
			.HeadAlignment = 0
            '.HeadFont = VB6.FontChangeBold(.HeadFont, True)
            .Width = 700
            .Locked = True
		End With
		With tdbgRoute.Columns(1)
			.Caption = "Days"
			.HeadAlignment = 0
            '.HeadFont = VB6.FontChangeBold(.HeadFont, True)
            .Width = 600
			.Locked = True
			With .ValueItems
				vItem.Value = 1
				vItem.DisplayValue = "M-F"
				.Add(vItem)
				vItem.Value = 2
				vItem.DisplayValue = "SAT"
				.Add(vItem)
				vItem.Value = 3
				vItem.DisplayValue = "SUN"
				.Add(vItem)
				.Translate = True
			End With
		End With
		With tdbgRoute.Columns(2)
			.Caption = "Dir"
			.HeadAlignment = 0
            '.HeadFont = VB6.FontChangeBold(.HeadFont, True)
            .Width = 600
			.Locked = True
			With .ValueItems
				vItem.Value = 0
				vItem.DisplayValue = "N"
				.Add(vItem)
				vItem.Value = 1
				vItem.DisplayValue = "S"
				.Add(vItem)
				vItem.Value = 2
				vItem.DisplayValue = "E"
				.Add(vItem)
				vItem.Value = 3
				vItem.DisplayValue = "W"
				.Add(vItem)
				vItem.Value = 4
				vItem.DisplayValue = "C"
				.Add(vItem)
				vItem.Value = 5
				vItem.DisplayValue = "A"
				.Add(vItem)
				.Translate = True
			End With
		End With
		With tdbgRoute.Columns(3)
			.Caption = "Differences"
			.HeadAlignment = 0
            '.HeadFont = VB6.FontChangeBold(.HeadFont, True)
            .Width = 6000
			.Locked = True
		End With
		Exit Sub
ErrHandling: 
		MsgBox("Error occurred while initializing.", MsgBoxStyle.Exclamation, AppTitle)
	End Sub
	
	Private Sub GridRouteRead()
		Dim strSQL As String
		Dim rsRoute As New ADODB.Recordset
		Dim i As Integer
		
		On Error GoTo ErrHandling
		strSQL = "select route,days,dir,differences from QAQC_Log order by route,days,dir"
        rsRoute.Open(strSQL, db, ADODB.CursorTypeEnum.adOpenStatic, ADODB.LockTypeEnum.adLockReadOnly)
        'Create_XArrayDB(rsRoute, xaRoute)
        tdbgRoute.Array = xaRoute
		tdbgRoute.ReBind()
		rsRoute.Close()
        rsRoute = Nothing
        Exit Sub
ErrHandling: 
		MsgBox("Error accessing database.", MsgBoxStyle.Exclamation, AppTitle)
	End Sub
	
	Private Sub cmdClose_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdClose.Click
		Me.Close()
	End Sub
	
	Private Sub cmdPrint_Click(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles cmdPrint.Click
		With tdbgRoute.PrintInfo
			.PageHeaderFont = VB6.FontChangeItalic(.PageHeaderFont, True)
			.PageHeader = "Time Tables QA/QC Comparison"
			.RepeatColumnHeaders = True
			.PageFooter = "\tPage: \p"
			.PrintPreview()
		End With
	End Sub
	
	Private Sub frmQAQC_Load(ByVal eventSender As System.Object, ByVal eventArgs As System.EventArgs) Handles MyBase.Load
		GridRouteInit()
		GridRouteRead()
	End Sub
End Class