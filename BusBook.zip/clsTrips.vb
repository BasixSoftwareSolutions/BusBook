Option Strict Off
Option Explicit On
Friend Class clsTrips
	Implements System.Collections.IEnumerable
    'clsTrips is a wrapper of collection class.
    'It works like collection, except it only contains one type of objects.
    'Its Add method automatically creates a Trip object.

    Private m_Trips As Collection
	
	Public ReadOnly Property Count() As Integer
		Get
			Count = m_Trips.Count()
		End Get
	End Property
	
	Public ReadOnly Property Item(ByVal index As String) As clsTrip
		Get
			Item = m_Trips.Item(index)
		End Get
	End Property

    'Public ReadOnly Property NewEnum() As stdole.IUnknown
    'Get
    'NewEnum = m_Trips._NewEnum
    'End Get
    'End Property

    Public Function GetEnumerator() As System.Collections.IEnumerator Implements System.Collections.IEnumerable.GetEnumerator
        GetEnumerator = m_Trips.GetEnumerator
    End Function
	
	Public Sub Add(ByRef tid As String)
		Dim trip As New clsTrip
		trip.TripID = tid
		m_Trips.Add(trip, tid)
	End Sub
	
	Public Sub Remove(ByRef index As String)
		m_Trips.Remove(index)
	End Sub
	
	Public Sub Sort(ByRef stops As clsStops)
		Dim arrTripID() As String
		Dim t As clsTrip
		Dim i As Short
		Dim j As Short
		Dim NewTrips As New Collection

        'store TripID into array
        ReDim arrTripID(m_Trips.Count())
        i = 1
		For	Each t In m_Trips
			arrTripID(i) = t.TripID
			i = i + 1
		Next t
		'sort trips in a way they should appear in bus book
		For i = 1 To m_Trips.Count() - 1
			For j = i + 1 To m_Trips.Count()
				CompareTrip(arrTripID(i), arrTripID(j), stops)
			Next j
		Next i
		'create new collection
		For i = 1 To m_Trips.Count()
			NewTrips.Add(m_Trips.Item(arrTripID(i)), arrTripID(i))
		Next i

        m_Trips = Nothing
        m_Trips = NewTrips
	End Sub

    Private Sub Class_Initialize_Renamed()
        m_Trips = New Collection
    End Sub
    Public Sub New()
		MyBase.New()
		Class_Initialize_Renamed()
	End Sub

    Private Sub Class_Terminate_Renamed()
        m_Trips = Nothing
    End Sub
    Protected Overrides Sub Finalize()
		Class_Terminate_Renamed()
		MyBase.Finalize()
	End Sub

    'Check one stop at a time in the Stops collection
    'to see if it matches a place_id of a timepoint in the current trip,
    'as well as one in the comparing trip, if it is found in both trips,
    'then compare the time of the two timepoints.
    'The trip with the earlier time is in precedence.
    'If no stop find matches in both trips,
    'then simple compare the time of their first timepoint.
    'The trip with the earlier time is in precedence.
    Private Sub CompareTrip(ByRef first As String, ByRef second_Renamed As String, ByRef stops As clsStops)
        Dim fIdx As Integer
        Dim sIdx As Integer
        Dim fTrip As clsTrip
        Dim sTrip As clsTrip
        Dim temp As String
        Dim s As clsStop

        fTrip = m_Trips.Item(first)
        sTrip = m_Trips.Item(second_Renamed)

        'search for common stop in both trip
        For Each s In stops
            For fIdx = 1 To fTrip.TimePoints.Count
                If s.PlaceID = fTrip.TimePoints.Item(fIdx).PlaceID Then
                    Exit For
                End If
            Next fIdx
            For sIdx = 1 To sTrip.TimePoints.Count
                If s.PlaceID = sTrip.TimePoints.Item(sIdx).PlaceID Then
                    Exit For
                End If
            Next sIdx
            If fIdx <= fTrip.TimePoints.Count And sIdx <= sTrip.TimePoints.Count Then
                'common stop found, exit search
                Exit For
            End If
        Next s
        If fIdx <= fTrip.TimePoints.Count And sIdx <= sTrip.TimePoints.Count Then
            'compare time for the common stop
            If sTrip.TimePoints.Item(CInt(CStr(sIdx))).time < fTrip.TimePoints.Item(CInt(CStr(fIdx))).time Then
                temp = first
                first = second_Renamed
                second_Renamed = temp
            End If
        Else 'no common stop
            'compare the first timepoint in each of these trips
            If sTrip.TimePoints.Item(1).time < fTrip.TimePoints.Item(1).time Then
                temp = first
                first = second_Renamed
                second_Renamed = temp
            End If
        End If
    End Sub
End Class