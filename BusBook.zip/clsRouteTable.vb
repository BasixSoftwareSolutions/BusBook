Option Strict Off
Option Explicit On
Friend Class clsRouteTable
	
	Public Trips As clsTrips
	Public Stops As clsStops
	Private m_RouteID As String
	Private m_Days As Short
    Private m_Direction As Short


    Public Property RouteID() As String
		Get
			RouteID = m_RouteID
		End Get
		Set(ByVal Value As String)
			m_RouteID = Value
		End Set
	End Property
	
	
	Public Property Days() As Short
		Get
			Days = m_Days
		End Get
		Set(ByVal Value As Short)
			m_Days = Value
		End Set
	End Property


    Public Property Direction() As Short
        Get
            Direction = m_Direction
        End Get
        Set(ByVal Value As Short)
            m_Direction = Value
        End Set
    End Property

    Private Sub Class_Initialize_Renamed()
        Trips = New clsTrips
        Stops = New clsStops
    End Sub
    Public Sub New()
		MyBase.New()
		Class_Initialize_Renamed()
	End Sub

    Private Sub Class_Terminate_Renamed()
        Trips = Nothing
        Stops = Nothing
    End Sub
    Protected Overrides Sub Finalize()
		Class_Terminate_Renamed()
		MyBase.Finalize()
	End Sub
End Class