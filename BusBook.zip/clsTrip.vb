Option Strict Off
Option Explicit On
Friend Class clsTrip
	
	Public TimePoints As clsTimePoints 'collection of timepoints
	Private m_TripID As String

    Public Property TripID() As String
		Get
			TripID = m_TripID
		End Get
		Set(ByVal Value As String)
			m_TripID = Value
		End Set
	End Property

    Private Sub Class_Initialize_Renamed()
        TimePoints = New clsTimePoints
    End Sub
    Public Sub New()
		MyBase.New()
		Class_Initialize_Renamed()
	End Sub

    Private Sub Class_Terminate_Renamed()
        TimePoints = Nothing
    End Sub
    Protected Overrides Sub Finalize()
		Class_Terminate_Renamed()
		MyBase.Finalize()
	End Sub
End Class