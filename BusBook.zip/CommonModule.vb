Option Strict Off
Option Explicit On
Module CommonModule

    Public Declare Function GetTickCount Lib "kernel32" () As Integer
    Public Declare Auto Function SetParent Lib "user32" (ByVal hWndChild As IntPtr, ByVal nWndPArent As IntPtr) As Integer
    Public frm As Form

    Public Sub wait(ByVal dblMilliseconds As Double)
        Dim dblStart As Double
        Dim dblEnd As Double
        Dim dblTickCount As Double

        dblTickCount = GetTickCount()
        dblStart = GetTickCount()
        dblEnd = GetTickCount + dblMilliseconds

        Do
            System.Windows.Forms.Application.DoEvents()
            dblTickCount = GetTickCount()
        Loop Until dblTickCount > dblEnd Or dblTickCount < dblStart


    End Sub


    Function cV2Q_String(ByRef V As Object) As String

        If IsDBNull(V) Or V = "" Then
            cV2Q_String = "NULL"
        Else
            cV2Q_String = "'" & Replace(V, "'", "''") & "'"
        End If

    End Function

    Public Function FilterNull(ByRef strString As Object) As Object

        If strString Is Nothing OrElse strString Is DBNull.Value Then
            FilterNull = ""
        Else
            FilterNull = Trim(strString)
        End If

    End Function

    Function IsInteger(ByRef V As Object) As Boolean

        IsInteger = False
        If IsNumeric(V) Then
            If CInt(V) = V Then
                IsInteger = True
            End If
        End If

    End Function

End Module