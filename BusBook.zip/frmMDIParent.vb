﻿Imports System.Windows.Forms

Public Class frmMDIParent

    Private Sub ShowNewForm(ByVal sender As Object, ByVal e As EventArgs)

        ' Create a new instance of the child form.
        Dim ChildForm As New System.Windows.Forms.Form
        ' Make it a child of this MDI form before showing it.
        ChildForm.MdiParent = Me
        m_ChildFormNumber += 1
        ChildForm.Text = "Window " & m_ChildFormNumber

        ChildForm.Show()

    End Sub

    Private Sub OpenFile(ByVal sender As Object, ByVal e As EventArgs)
        Dim OpenFileDialog As New OpenFileDialog
        OpenFileDialog.InitialDirectory = My.Computer.FileSystem.SpecialDirectories.MyDocuments
        OpenFileDialog.Filter = "Text Files (*.txt)|*.txt|All Files (*.*)|*.*"
        If (OpenFileDialog.ShowDialog(Me) = System.Windows.Forms.DialogResult.OK) Then
            Dim FileName As String = OpenFileDialog.FileName
        End If
    End Sub

    Private Sub SaveAsToolStripMenuItem_Click(ByVal sender As Object, ByVal e As EventArgs)
        Dim SaveFileDialog As New SaveFileDialog
        SaveFileDialog.InitialDirectory = My.Computer.FileSystem.SpecialDirectories.MyDocuments
        SaveFileDialog.Filter = "Text Files (*.txt)|*.txt|All Files (*.*)|*.*"

        If (SaveFileDialog.ShowDialog(Me) = System.Windows.Forms.DialogResult.OK) Then
            Dim FileName As String = SaveFileDialog.FileName
        End If
    End Sub


    Private Sub ExitToolsStripMenuItem_Click(ByVal sender As Object, ByVal e As EventArgs)
        Me.Close()
    End Sub

    Private Sub CascadeToolStripMenuItem_Click(ByVal sender As Object, ByVal e As EventArgs)
        Me.LayoutMdi(MdiLayout.Cascade)
    End Sub

    Private Sub TileVerticalToolStripMenuItem_Click(ByVal sender As Object, ByVal e As EventArgs)
        Me.LayoutMdi(MdiLayout.TileVertical)
    End Sub

    Private Sub TileHorizontalToolStripMenuItem_Click(ByVal sender As Object, ByVal e As EventArgs)
        Me.LayoutMdi(MdiLayout.TileHorizontal)
    End Sub

    Private Sub ArrangeIconsToolStripMenuItem_Click(ByVal sender As Object, ByVal e As EventArgs)
        Me.LayoutMdi(MdiLayout.ArrangeIcons)
    End Sub

    Private Sub CloseAllToolStripMenuItem_Click(ByVal sender As Object, ByVal e As EventArgs)
        ' Close all child forms of the parent.
        For Each ChildForm As Form In Me.MdiChildren
            ChildForm.Close()
        Next
    End Sub

    Private Sub frmMDIParent_Load(sender As Object, e As EventArgs) Handles Me.Load

        Call CreateConnection()

        frm = New frmHome
        SetParent(frm.Handle, Me.SplitContainer2.Panel2.Handle)
        frm.Location = New Point(0, 0)
        frm.Size = SplitContainer2.Panel2.Size
        frm.Show()

    End Sub

    Private m_ChildFormNumber As Integer

    Private Sub cmdImport_Click(sender As Object, e As EventArgs) Handles cmdImport.Click
        On Error GoTo ErrHandler

        CloseForms()
        frm = New frmPTDestination
        SetParent(frm.Handle, Me.SplitContainer2.Panel2.Handle)
        frm.Location = New Point(0, 0)
        frm.Show()

        Exit Sub

ErrHandler:
        MsgBox(Err.Source & ": " & Err.Description, MsgBoxStyle.Exclamation, System.Reflection.Assembly.GetExecutingAssembly.GetName.Name)

    End Sub

    Private Function CloseForms() As Boolean
        Dim aFormNames() As String = {"frmHome", "frmPTDestination", "frmBusRouteDescription", "frmDestination", "frmLandMarkAlias", "frmLayoverZones", "frmRoute", "frmRouteTP"}
        Dim i As Integer

        For Each frm As Form In Application.OpenForms
            For i = 0 To aFormNames.GetUpperBound(0)
                If frm.Name.Equals(aFormNames(i)) Then
                    frm.Close()
                    Exit Function
                End If
            Next i
        Next frm

    End Function

    Private Sub cmdBusRouteDescriptions_Click(sender As Object, e As EventArgs) Handles cmdBusRouteDescriptions.Click
        On Error GoTo ErrHandler

        CloseForms()
        frm = New frmBusRouteDescription
        SetParent(frm.Handle, Me.SplitContainer2.Panel2.Handle)
        frm.Location = New Point(0, 0)
        frm.Show()

        Exit Sub

ErrHandler:
        MsgBox(Err.Source & ": " & Err.Description, MsgBoxStyle.Exclamation, System.Reflection.Assembly.GetExecutingAssembly.GetName.Name)

    End Sub

    Private Sub cmdLayoverZones_Click(sender As Object, e As EventArgs) Handles cmdLayoverZones.Click
        On Error GoTo ErrHandler

        CloseForms()
        frm = New frmLayoverZones
        SetParent(frm.Handle, Me.SplitContainer2.Panel2.Handle)
        frm.Location = New Point(0, 0)
        frm.Show()

        Exit Sub

ErrHandler:
        MsgBox(Err.Source & ": " & Err.Description, MsgBoxStyle.Exclamation, System.Reflection.Assembly.GetExecutingAssembly.GetName.Name)

    End Sub

    Private Sub cmdLandmarkAlias_Click(sender As Object, e As EventArgs) Handles cmdLandmarkAlias.Click
        On Error GoTo ErrHandler

        CloseForms()
        frm = New frmLandMarkAlias
        SetParent(frm.Handle, Me.SplitContainer2.Panel2.Handle)
        frm.Location = New Point(0, 0)
        frm.Show()

        Exit Sub

ErrHandler:
        MsgBox(Err.Source & ": " & Err.Description, MsgBoxStyle.Exclamation, System.Reflection.Assembly.GetExecutingAssembly.GetName.Name)

    End Sub

    Private Sub cmdBook_Click(sender As Object, e As EventArgs) Handles cmdBook.Click

        On Error GoTo lblMdbErr

        CloseForms()
        frm = New frmRoute
        SetParent(frm.Handle, Me.SplitContainer2.Panel2.Handle)
        frm.Location = New Point(0, 0)
        frm.Show()

        Exit Sub

lblMdbErr:
        MsgBox(Err.Source & ": " & Err.Description, MsgBoxStyle.Exclamation, System.Reflection.Assembly.GetExecutingAssembly.GetName.Name)
        Exit Sub

    End Sub

    Private Sub cmdViewTP_Click(sender As Object, e As EventArgs) Handles cmdViewTP.Click

        On Error GoTo ErrHandler

        CloseForms()
        frm = New frmRouteTP
        SetParent(frm.Handle, Me.SplitContainer2.Panel2.Handle)
        frm.Location = New Point(0, 0)
        frm.Show()

        Exit Sub

ErrHandler:
        MsgBox(Err.Source & ": " & Err.Description, MsgBoxStyle.Exclamation, System.Reflection.Assembly.GetExecutingAssembly.GetName.Name)

    End Sub

    Private Sub cmdLayover_Click(sender As Object, e As EventArgs) Handles cmdLayover.Click

        On Error GoTo ErrHandler

        CloseForms()
        frm = New frmManageLayoverZones
        SetParent(frm.Handle, Me.SplitContainer2.Panel2.Handle)
        frm.Location = New Point(0, 0)
        frm.Show()

        Exit Sub

ErrHandler:
        MsgBox(Err.Source & ": " & Err.Description, MsgBoxStyle.Exclamation, System.Reflection.Assembly.GetExecutingAssembly.GetName.Name)

    End Sub

    Private Sub cmdHome_Click(sender As Object, e As EventArgs) Handles cmdHome.Click

        On Error GoTo ErrHandler

        CloseForms()
        frm = New frmHome
        SetParent(frm.Handle, Me.SplitContainer2.Panel2.Handle)
        frm.Location = New Point(0, 0)
        frm.Size = SplitContainer2.Panel2.Size
        frm.Show()

        Exit Sub

ErrHandler:
        MsgBox(Err.Source & ": " & Err.Description, MsgBoxStyle.Exclamation, System.Reflection.Assembly.GetExecutingAssembly.GetName.Name)

    End Sub

    Private Sub cmdExit_Click(sender As Object, e As EventArgs) Handles cmdExit.Click

        Me.Close()

    End Sub
End Class
